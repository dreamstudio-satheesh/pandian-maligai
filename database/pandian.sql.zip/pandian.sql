SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;


CREATE TABLE `accounts` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_num` varchar(192) NOT NULL,
  `account_name` varchar(192) NOT NULL,
  `initial_balance` decimal(10,2) NOT NULL,
  `note` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `audit_logs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED DEFAULT NULL,
  `event` varchar(255) NOT NULL,
  `auditable_type` varchar(255) NOT NULL,
  `auditable_id` bigint(20) UNSIGNED NOT NULL,
  `old_values` text DEFAULT NULL,
  `new_values` text DEFAULT NULL,
  `url` varchar(255) DEFAULT NULL,
  `ip_address` varchar(255) DEFAULT NULL,
  `user_agent` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `brands` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `brands` (`id`, `name`, `created_by`, `deleted_by`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'TATA', NULL, NULL, NULL, '2024-05-14 09:11:43', '2024-05-14 09:11:43');

CREATE TABLE `categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `parent_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `currencies` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `code` varchar(192) NOT NULL,
  `name` varchar(192) NOT NULL,
  `symbol` varchar(192) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `currencies` (`id`, `code`, `name`, `symbol`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'USD', 'US Dollar', '$', NULL, NULL, NULL),
(2, 'EUR', 'Euro', '€', NULL, NULL, NULL),
(3, 'JPY', 'Japanese Yen', '¥', NULL, NULL, NULL),
(4, 'GBP', 'British Pound', '£', NULL, NULL, NULL),
(5, 'AUD', 'Australian Dollar', 'A$', NULL, NULL, NULL),
(6, 'CAD', 'Canadian Dollar', 'C$', NULL, NULL, NULL),
(7, 'CHF', 'Swiss Franc', 'CHF', NULL, NULL, NULL),
(8, 'CNY', 'Chinese Yuan', '¥', NULL, NULL, NULL),
(9, 'SEK', 'Swedish Krona', 'kr', NULL, NULL, NULL),
(10, 'NZD', 'New Zealand Dollar', 'NZ$', NULL, NULL, NULL),
(11, 'INR', 'Indian Rupee', '₹', NULL, NULL, NULL),
(12, 'BRL', 'Brazilian Real', 'R$', NULL, NULL, NULL),
(13, 'ZAR', 'South African Rand', 'R', NULL, NULL, NULL),
(14, 'RUB', 'Russian Ruble', '₽', NULL, NULL, NULL),
(15, 'MXN', 'Mexican Peso', '$', NULL, NULL, NULL),
(16, 'SGD', 'Singapore Dollar', 'S$', NULL, NULL, NULL),
(17, 'HKD', 'Hong Kong Dollar', 'HK$', NULL, NULL, NULL);

CREATE TABLE `customers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(192) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `customers` (`id`, `name`, `phone`, `email`, `address`, `created_by`, `deleted_by`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Walk-in Customer', NULL, NULL, NULL, NULL, NULL, NULL, '2024-03-10 22:01:33', '2024-03-10 22:01:33'),
(2, 'RAJANTRAN NMK', NULL, NULL, NULL, NULL, NULL, NULL, '2024-05-13 07:17:34', '2024-05-13 07:17:34');

CREATE TABLE `deposits` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `deposit_category_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `deposit_ref` varchar(192) NOT NULL,
  `description` text DEFAULT NULL,
  `attachment` varchar(192) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `deposit_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(192) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `expenses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) NOT NULL,
  `expense_category_id` int(11) NOT NULL,
  `amount` decimal(10,2) NOT NULL,
  `payment_method_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `expense_ref` varchar(192) NOT NULL,
  `description` text DEFAULT NULL,
  `attachment` varchar(192) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `expense_categories` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(192) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `failed_jobs` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `media` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `model_type` varchar(255) NOT NULL,
  `model_id` bigint(20) UNSIGNED NOT NULL,
  `uuid` char(36) DEFAULT NULL,
  `collection_name` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `mime_type` varchar(255) DEFAULT NULL,
  `disk` varchar(255) NOT NULL,
  `conversions_disk` varchar(255) DEFAULT NULL,
  `size` bigint(20) UNSIGNED NOT NULL,
  `manipulations` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`manipulations`)),
  `custom_properties` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`custom_properties`)),
  `generated_conversions` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`generated_conversions`)),
  `responsive_images` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`responsive_images`)),
  `order_column` int(10) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `migrations` (
  `id` int(10) UNSIGNED NOT NULL,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `migrations` (`id`, `migration`, `batch`) VALUES
(1, '2014_10_12_000000_create_users_table', 1),
(2, '2014_10_12_100000_create_password_reset_tokens_table', 1),
(3, '2014_10_12_100000_create_password_resets_table', 1),
(4, '2019_08_19_000000_create_failed_jobs_table', 1),
(5, '2019_12_14_000001_create_personal_access_tokens_table', 1),
(6, '2023_11_09_001057_create_product_variants_table', 1),
(7, '2023_11_09_131309_create_products_table', 1),
(8, '2023_11_10_131210_create_customers_table', 1),
(9, '2023_11_10_131211_create_categories_table', 1),
(10, '2023_11_10_131306_create_suppliers_table', 1),
(11, '2023_11_10_131335_create_stocks_table', 1),
(12, '2023_11_10_131553_create_audit_logs_table', 1),
(13, '2023_11_22_053423_create_settings_table', 1),
(14, '2023_12_02_103023_create_brands_table', 1),
(15, '2023_12_02_124859_create_media_table', 1),
(16, '2023_12_03_143706_create_units_table', 1),
(17, '2023_12_04_051427_create_warehouses_table', 1),
(18, '2023_12_09_122455_create_sales_table', 1),
(19, '2023_12_09_124125_create_purchases_table', 1),
(20, '2024_01_03_022925_create_transactions_table', 1),
(21, '2024_01_05_050918_create_sales_items_table', 1),
(22, '2024_01_05_092950_create_purchases_items', 1),
(23, '2024_01_28_052240_create_payment_methods_table', 1),
(24, '2024_01_28_060218_create_accounts_table', 1),
(25, '2024_01_28_060541_create_deposits_table', 1),
(26, '2024_01_28_060601_create_deposit_categories_table', 1),
(27, '2024_01_28_060627_create_expenses_table', 1),
(28, '2024_01_28_060634_create_expense_categories_table', 1),
(29, '2024_01_29_052226_create_currencies_table', 1),
(30, '2024_01_30_131120_create_payment_sales_table', 1),
(31, '2024_01_30_132258_create_payment_purchases_table', 1),
(32, '2024_02_19_123600_create_sales_returns_table', 1),
(33, '2024_02_19_123601_create_purchase_returns_table', 1),
(34, '2024_02_19_123601_create_sales_return_items_table', 1),
(35, '2024_02_19_123602_create_purchase_return_items_table', 1),
(36, '2024_02_21_084127_create_sales_return_payments_table', 1),
(37, '2024_02_21_084135_create_purchase_return_payments_table', 1),
(38, '2024_02_28_191355_create_roles_table', 1),
(39, '2024_02_28_191510_create_permissions_table', 1),
(40, '2024_02_28_191539_create_role_permission_table', 1),
(41, '2024_02_28_202815_add_role_id_to_users_table', 1),
(42, '2024_02_29_191854_create_permission_groups_table', 1),
(43, '2024_03_03_180428_create_transfers_table', 1),
(44, '2024_03_03_180449_create_transfers_items_table', 1);

CREATE TABLE `password_resets` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `password_reset_tokens` (
  `username` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `payment_methods` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `title` varchar(192) NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `payment_methods` (`id`, `title`, `is_default`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'Cash', 1, NULL, '2024-03-10 22:01:33', '2024-03-10 22:01:33'),
(2, 'Credit Card', 0, NULL, '2024-03-10 22:01:33', '2024-03-10 22:01:33'),
(3, 'Check', 0, NULL, '2024-03-10 22:01:33', '2024-03-10 22:01:33'),
(4, 'Bank Transfer', 0, NULL, '2024-03-10 22:01:33', '2024-03-10 22:01:33');

CREATE TABLE `payment_purchases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `payment_method_id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `change` double NOT NULL DEFAULT 0,
  `payment_notes` varchar(192) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `payment_sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sale_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `payment_method_id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `change` double NOT NULL DEFAULT 0,
  `payment_notes` varchar(192) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `permissions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `group_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permissions` (`id`, `name`, `description`, `group_id`, `created_at`, `updated_at`) VALUES
(1, 'view_dashboard', 'Access the main dashboard.', 1, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(2, 'create_users', 'Add new users to the system.', 2, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(3, 'view_users', 'View user profiles and lists.', 2, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(4, 'edit_users', 'Edit user information.', 2, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(5, 'delete_users', 'Remove users from the system.', 2, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(6, 'manage_roles', 'Manage User roles.', 3, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(7, 'create_products', 'Add new products.', 4, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(8, 'view_products', 'View product listings.', 4, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(9, 'edit_products', 'Update product details.', 4, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(10, 'delete_products', 'Remove products from the catalog.', 4, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(11, 'print_labels', 'Manage Print Labels', 4, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(12, 'manage_categories', 'Manage product categories.', 5, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(13, 'manage_brands', 'Manage brands.', 6, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(14, 'manage_units', 'Manage units.', 7, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(15, 'manage_warehouses', 'Manage warehouses.', 8, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(16, 'view_all_stocks', 'View All Users Stocks.', 9, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(17, 'view_own_stocks', 'View Only Current User Stock.', 9, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(18, 'create_stocks', 'Add new Stocks.', 9, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(19, 'manage_stocks', 'View Stocks listings.', 9, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(20, 'view_all_sales', 'Access All Sale Records.', 10, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(21, 'view_own_sales', 'View Only Current User Sale Record.', 10, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(22, 'create_sales', 'Process new sales transactions.', 10, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(23, 'view_sales', 'View sales order records.', 10, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(24, 'edit_sales', 'Modify sales transactions.', 10, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(25, 'delete_sales', 'Cancel or remove sales transactions.', 10, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(26, 'show_pos', 'Access POS Page.', 10, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(27, 'view_all_purchase', 'Access All Purchase Records.', 11, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(28, 'view_own_purchase', 'View Only Current User Purchase Record.', 11, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(29, 'create_purchases', 'Create purchase orders.', 11, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(30, 'view_purchases', 'View purchase order records.', 11, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(31, 'edit_purchases', 'Edit purchase orders.', 11, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(32, 'delete_purchases', 'Cancel or delete purchase orders.', 11, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(33, 'create_account', 'Add new Account.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(34, 'view_account', 'View Account information.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(35, 'edit_account', 'Update Account details.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(36, 'delete_account', 'Remove Account from the system.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(37, 'create_deposit', 'Add new Deposit.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(38, 'view_deposit', 'View Deposit information.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(39, 'edit_deposit', 'Update Deposit details.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(40, 'delete_deposit', 'Remove Deposit from the system.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(41, 'manage_deposit_categories', 'Manage Deposit Category.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(42, 'create_expense', 'Add new Expense.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(43, 'view_expense', 'View Expense information.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(44, 'edit_expense', 'Update Expense details.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(45, 'delete_expense', 'Remove Expense from the system.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(46, 'manage_expense_categories', 'Manage Expense Category.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(47, 'manage_payment_methods', 'Manage Payment Methods.', 12, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(48, 'generate_reports', 'Generate sales, purchases, and other reports.', 13, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(49, 'system_settings', 'Modify system settings.', 14, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(50, 'module_settings', 'Modify Module settings.', 14, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(51, 'manage_currencies', 'Add or edit currencies.', 14, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(52, 'view_all_suppliers', 'Access All suppliers Records.', 15, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(53, 'view_own_suppliers', 'View Only Current Users suppliers Records.', 15, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(54, 'manage_suppliers', 'Manage supplier information.', 15, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(55, 'view_all_customers', 'Access All customers Records.', 16, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(56, 'view_own_Customers', 'View Only Current Users Customers Records.', 16, '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(57, 'manage_customers', 'View customer information.', 16, '2024-03-10 22:01:34', '2024-03-10 22:01:34');

CREATE TABLE `permission_groups` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `permission_groups` (`id`, `name`, `description`, `created_at`, `updated_at`) VALUES
(1, 'Dashboard', 'Permissions related to dashboard access and overview.', '2024-03-10 22:01:33', '2024-03-10 22:01:33'),
(2, 'User Management', 'Permissions for managing users including creating, viewing, editing, and deleting users.', '2024-03-10 22:01:33', '2024-03-10 22:01:33'),
(3, 'Roles and Permissions', 'Permissions to manage roles and permissions.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(4, 'Product Management', 'Permissions for managing products including adding, viewing, editing, and deleting products.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(5, 'Category Management', 'Permissions for managing product categories.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(6, 'Brands Management', 'Permissions for managing brands.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(7, 'Units Management', 'Permissions for managing units of measurement.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(8, 'Warehouse Management', 'Permissions for managing warehouses.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(9, 'Stock Management', 'Permissions related to stock management including viewing, adding, editing, and deleting stocks.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(10, 'Sales Management', 'Permissions related to sales management.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(11, 'Purchase Orders Management', 'Permissions related to managing purchase orders.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(12, 'Financial Transactions', 'Permissions related to managing financial transactions.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(13, 'Reports', 'Permissions for generating various reports.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(14, 'Settings and Configuration', 'Permissions for modifying system and module settings.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(15, 'Supplier Management', 'Permissions for managing suppliers.', '2024-03-10 22:01:34', '2024-03-10 22:01:34'),
(16, 'Customer Management', 'Permissions for managing customers.', '2024-03-10 22:01:34', '2024-03-10 22:01:34');

CREATE TABLE `personal_access_tokens` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `tokenable_type` varchar(255) NOT NULL,
  `tokenable_id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `token` varchar(64) NOT NULL,
  `abilities` text DEFAULT NULL,
  `last_used_at` timestamp NULL DEFAULT NULL,
  `expires_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `products` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `name_ta` varchar(255) DEFAULT NULL,
  `sku` varchar(255) NOT NULL,
  `description` text DEFAULT NULL,
  `price` decimal(8,2) DEFAULT NULL,
  `cost` decimal(8,2) DEFAULT NULL,
  `product_type` varchar(50) NOT NULL,
  `tax_method` varchar(10) DEFAULT 'exclusive',
  `unit_id` bigint(20) UNSIGNED DEFAULT NULL,
  `unit_sale_id` bigint(20) UNSIGNED DEFAULT NULL,
  `unit_purchase_id` bigint(20) UNSIGNED DEFAULT NULL,
  `tax` decimal(5,2) DEFAULT 0.00,
  `category_id` bigint(20) UNSIGNED DEFAULT NULL,
  `supplier_id` bigint(20) UNSIGNED DEFAULT NULL,
  `brand_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `minimum_sale_quantity` int(11) NOT NULL DEFAULT 1,
  `stock_alert` int(11) DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `products` (`id`, `name`, `name_ta`, `sku`, `description`, `price`, `cost`, `product_type`, `tax_method`, `unit_id`, `unit_sale_id`, `unit_purchase_id`, `tax`, `category_id`, `supplier_id`, `brand_id`, `created_by`, `minimum_sale_quantity`, `stock_alert`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'thuvaram paruppu 1', 'துவரம் பருப்பு ', '001', NULL, 175.00, 175.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:07:48', NULL),
(2, 'pasi paruppu', 'பாசி பருப்பு ', '002', NULL, 125.00, 125.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(3, 'pachai kadali paruppu', 'பச்சை கடலை பருப்பு ', '003', NULL, 96.00, 96.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(4, 'uruttu uluntha paruppu', 'உருட்டு உளுந்து பருப்பு ', '004', NULL, 140.00, 140.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 07:20:03', NULL),
(5, 'pottu uluntha paruppu', 'பொட்டு உளுந்து பருப்பு  ', '005', NULL, 130.00, 130.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(6, 'pattri paruppu', 'பட்ரி பருப்பு ', '006', NULL, 85.00, 85.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 08:03:55', NULL),
(7, 'udaiththa uluntha paruppu', 'உடைத்த உளுந்து பருப்பு ', '007', NULL, 125.00, 125.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 08:04:13', NULL),
(8, 'varugakadalai', 'வருகடலை', '008', NULL, 135.00, 135.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 08:25:17', NULL),
(9, 'neelakadali', 'நில கடலை ', '009', NULL, 150.00, 150.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:08:17', NULL),
(10, 'pashi pairu', 'பாசி பயிறு ', '010', NULL, 130.00, 130.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:56:45', NULL),
(11, 'karuppu sundal', 'கருப்பு சுண்டல் ', '011', NULL, 96.00, 96.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(12, 'vellai sundal', 'வெள்ளை சுண்டல்', '012', NULL, 180.00, 180.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(13, 'Pachai pattani', 'பச்சை பட்டாணி ', '013', NULL, 110.00, 110.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:59:29', NULL),
(14, 'thattai pairu', 'தட்டை பயிறு ', '014', NULL, 95.00, 95.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:57:03', NULL),
(15, 'por mochchai', 'போர் மொச்சை ', '015', NULL, 145.00, 145.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 12:28:48', NULL),
(16, 'KAANAM', 'காணம்', '016', NULL, 85.00, 85.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:56:30', NULL),
(17, 'SUNDA VATHTHAL', 'சுண்ட வத்தல் ', '017', NULL, 380.00, 380.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(18, 'KUNDU VATHTHAL', 'குண்டு வத்தல் ', '018', NULL, 240.00, 240.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 07:49:45', NULL),
(19, 'ANDHARA VATHTHAL', 'ஆந்திரா வத்தல் ', '019', NULL, 240.00, 240.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:09:17', NULL),
(20, 'KASMIR VATHTHAL', 'காஷ்மீர் வத்தல் ', '020', NULL, 260.00, 260.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:08:46', NULL),
(21, 'NATTU MALLI', 'நாட்டு மல்லி ', '021', NULL, 130.00, 130.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(22, 'GOTHUMAI', 'கோதுமை ', '022', NULL, 46.00, 46.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(23, 'MEEAL MAKER', 'மீள் மேக்கர் ', '023', NULL, 120.00, 120.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(24, 'SAKTHI MANJAL THUL', 'சக்தி மஞ்சள் தூள் ', '024', NULL, 240.00, 240.00, 'standard', 'exclusive', 1, 1, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 07:18:18', NULL),
(25, 'sakthi melaigai thul', 'சக்தி மிளகாய் தூள் ', '025', NULL, 290.00, 290.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:12:10', NULL),
(26, 'sakthi malli thul', 'சக்தி மல்லி தூள் ', '026', NULL, 190.00, 190.00, 'standard', 'exclusive', 1, 1, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:38:58', NULL),
(27, 'aachi badam mix 1set MRP 175', 'ஆச்சி பாதம் mix (1 set )MRP175', '027', NULL, 160.00, 160.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:53:55', NULL),
(28, 'aachi badam payasam mix', 'ஆச்சி பாயசம் mix (1 set )', '028', NULL, 110.00, 110.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(29, 'sakthi samber thul 500GMS', 'சக்தி சாம்பார் தூள் 500GMS', '029', NULL, 165.00, 165.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:33:28', NULL),
(30, 'sakthi kari  mashala', 'சக்தி கறிமசால்', '030', NULL, 400.00, 400.00, 'standard', 'exclusive', 1, 1, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 08:26:40', NULL),
(31, 'SAKTHI MUTTON MASHALA', 'சக்தி மட்டன் மசாலா ', '031', NULL, 420.00, 420.00, 'standard', 'exclusive', 1, 1, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 08:26:18', NULL),
(32, 'sakthi chikkan mashala', 'சக்தி சிக்கன் மசாலா ', '032', NULL, 340.00, 340.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:35:42', NULL),
(33, 'sakthi chikkan 65', 'சக்தி சில்லி 65', '033', NULL, 22.00, 22.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(34, 'SAKTHI MEEN MASALA 50gms', 'சக்தி மீன் வறுவல் 50gms', '034', NULL, 22.00, 22.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:17:53', NULL),
(35, 'SAKTHI MEEAN KULAMPU MASHALA 50gms', 'சக்தி மீன் குழம்பு 50gms', '035', NULL, 18.00, 18.00, 'standard', 'exclusive', 3, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:17:01', NULL),
(36, 'SAKTHI BRIYANI MASHALA 200GMS', 'சக்தி பிரியாணி மசாலா 200GMS', '036', NULL, 104.00, 104.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:48:45', NULL),
(37, 'SAKTHI GARAM MASHALA 50gms', 'சக்தி கரம் மசாலா 50gms', '037', NULL, 25.00, 25.00, 'standard', 'exclusive', 2, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:16:38', NULL),
(38, 'SAKTHI MELAGU THULL 50gms', 'சக்தி மிளகு தூள் 50gms', '038', NULL, 43.00, 43.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:18:33', NULL),
(39, 'SAKTHI SEERAGA THULL', 'சக்தி சீரகத்தூள் ', '039', NULL, 40.00, 40.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(40, 'SATHI RASHAM PODI', 'சக்தி ரசப்பொடி ', '040', NULL, 56.00, 56.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(41, 'SAKTHI IDLY PODI 100gms', 'சக்தி இட்லி பொடி 100gms', '041', NULL, 28.00, 28.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:19:01', NULL),
(42, 'SAKTHI chikkan mashalA 50 GMS', 'சக்தி சிக்கன் மசாலா 50GMS', '042', NULL, 18.00, 18.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:21:35', NULL),
(43, 'aachi chikkan 65', 'ஆச்சி சிக்கன் 65', '043', NULL, 22.00, 22.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(44, 'aachi kulampu masala 100GMS', 'ஆச்சி குழம்பு மிளகாய் தூள் 100GMS', '044', NULL, 35.00, 35.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 11:54:52', NULL),
(45, 'sakthi ragi mavu', 'சக்தி ராகி மாவு ', '045', NULL, 70.00, 70.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(46, 'sakthi bajji mavu', 'சக்தி பஜ்ஜி மாவு ', '046', NULL, 136.00, 136.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(47, 'chekku kadalai ennai jar', 'செக்கு jar கடலை எண்ணெய் ', '047', NULL, 210.00, 210.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 10:15:21', NULL),
(48, 'KADALAI ENNAI', 'கடலை எண்ணெய் ', '048', NULL, 190.00, 190.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:35:11', NULL),
(49, 'chekku thengaii ennai', 'செக்கு தேங்காய் எண்ணெய் ', '049', NULL, 220.00, 220.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(50, 'chekku nalla ennai', 'செக்கு நல்லெண்ணெய் ', '050', NULL, 380.00, 380.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(51, 'chekku velakku ennai', 'செக்கு விளக்கெண்ணெய் ', '051', NULL, 180.00, 180.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:17:55', NULL),
(52, 'UDHAYAM DEEPA ENNAI', 'உதயம் தீபம் எண்ணெய் ', '052', NULL, 120.00, 120.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 15:39:06', NULL),
(53, 'pooja oil 500MIL', 'pooja oil 500MIL', '053', NULL, 90.00, 90.00, 'standard', 'exclusive', 4, 4, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 07:59:00', NULL),
(54, 'Palm Oil ', 'Palm Oil ', '054', NULL, 85.00, 85.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(55, 'Gold Winner Oil  ', 'Gold Winner Oil  ', '055', NULL, 560.00, 560.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(56, 'Sun Flower Oil 5LI', 'Sun Flower Oil 5LI', '056', NULL, 570.00, 570.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:57:48', NULL),
(57, 'VVD தேங்காய் எண்ணெய் jar ', 'VVD தேங்காய் எண்ணெய் jar ', '057', NULL, 190.00, 190.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(58, 'VVD தேங்காய் எண்ணெய்500MIL ', 'VVD தேங்காய் எண்ணெய் 500MIL', '058', NULL, 105.00, 105.00, 'standard', 'exclusive', 3, 3, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 07:06:18', NULL),
(59, 'idhayam nalla ennai 500MIL', 'இதயம் நல்லெண்ணெய் (500MIL)', '059', NULL, 230.00, 230.00, 'standard', 'exclusive', 4, 4, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:58:37', NULL),
(60, 'Parachute தேங்காய் எண்ணெய் ', 'Parachute தேங்காய் எண்ணெய் ', '060', NULL, 158.00, 158.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(61, 'Ayurvedic Hair Oil ', 'Ayurvedic Hair Oil ', '061', NULL, 120.00, 120.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(62, 'Vatika Hair Oil ', 'Vatika Hair Oil ', '062', NULL, 175.00, 175.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(63, 'Dabur Amla Hair Oil ', 'Dabur Amla Hair Oil ', '063', NULL, 88.00, 88.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(64, 'Dabur Badam Hair Oil (1 set)', 'Dabur Badam Hair Oil (1 set)', '064', NULL, 68.00, 68.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(65, 'Hit Spray Black ', 'Hit Spray Black ', '065', NULL, 110.00, 110.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(66, 'Hit Spray Red ', 'Hit Spray Red ', '066', NULL, 90.00, 90.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(67, 'Hit Chalk MRP18', 'Hit Chalk [MRP18]', '067', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 11:06:09', NULL),
(68, 'gajapathi renfind kadali ennai', 'கஜபதி OIL 1LI', '068', NULL, 205.00, 205.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 07:02:32', NULL),
(69, 'ghee 1LI', ' நெய் 1LI', '069', NULL, 640.00, 640.00, 'standard', 'exclusive', 4, 4, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:04:31', NULL),
(70, 'Tata அவுள் ', 'Tata அவுள் ', '070', NULL, 40.00, 40.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(71, 'GOTHUMAI MAVU 5KG', 'கோதுமை மாவு  5KG', '071', NULL, 300.00, 300.00, 'standard', 'exclusive', 3, 3, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 09:05:22', NULL),
(72, 'MAIDA MAVU', 'கிளி மைதா மாவு ', '072', NULL, 55.00, 55.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:51:55', NULL),
(73, 'SMT arisi maavu', 'SMT அரிசி மாவு ', '073', NULL, 65.00, 65.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:52:12', NULL),
(74, 'prtiyam idiyappa mavu', 'ப்ரியம் இடியாப்ப மாவு ', '074', NULL, 98.00, 98.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:52:36', NULL),
(75, 'corn mavu', 'காண் மாவு ', '075', NULL, 65.00, 65.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(76, 'KADALAI MAVU', 'நயம் கடலை மாவு ', '076', NULL, 96.00, 96.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 08:05:11', NULL),
(77, 'mayil sampa ravai', 'மயில் சம்பா ரவை ', '077', NULL, 125.00, 125.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:49:47', NULL),
(78, 'vellai ravi pocket', 'வெள்ளை ரவை pocket ', '078', NULL, 70.00, 70.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(79, 'vellam', 'வெல்லம் ', '079', NULL, 65.00, 65.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(80, 'nattu sarkkarai', 'நாட்டு சர்க்கரை ', '080', NULL, 65.00, 65.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 08:09:39', NULL),
(81, 'kadugu', 'கடுகு ', '081', NULL, 120.00, 120.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(82, 'jeeragam', 'சீரகம் ', '082', NULL, 650.00, 650.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(83, 'melagu', 'மிளகு ', '083', NULL, 800.00, 800.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 06:14:24', NULL),
(84, 'vendhayamn', 'வெந்தயம் ', '084', NULL, 120.00, 120.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 07:21:31', NULL),
(85, 'sombu', 'சோம்பு ', '085', NULL, 500.00, 500.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:35:36', NULL),
(86, 'pattai', 'பட்டை ', '086', NULL, 300.00, 300.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:18:05', NULL),
(87, 'nayam puli', 'டும்கூர் நயம் புளி ', '087', NULL, 180.00, 180.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 12:23:41', NULL),
(88, 'chakkara gold 500GMS', 'சக்ரா gold tea 500GMS', '088', NULL, 280.00, 280.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 05:22:53', NULL),
(89, 'chakkara gold hotel tea', 'சக்ரா Gold Hotel Tea ', '089', NULL, 140.00, 140.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(90, 'AVT TEA 1KG', 'ஏவிடி டீ 1KG', '090', NULL, 280.00, 280.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 12:10:18', NULL),
(91, 'AVT COFFE 200GMS[ MRP110]', 'ஏவிடி காபி 200GMS[ MRP110]', '091', NULL, 105.00, 105.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 12:13:56', NULL),
(92, '3ROSE TEA 500GMS', 'திரி ரோஸஸ் டீ தூள் 500GMS', '092', NULL, 320.00, 340.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:51:25', NULL),
(93, '3ROSE TEA NC 250GMS (MEP240)', 'திரி ரோஸஸ் டீ NC 250GMS (MRP240)', '093', NULL, 235.00, 235.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 09:06:27', NULL),
(94, 'TAJ MAHAL TEA 2510GMS (MRP235)', 'தாஜ்மஹால் டீ 250GMS (MRP235)', '094', NULL, 230.00, 230.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 07:04:02', NULL),
(95, 'BRU Coffee 200GMS [MRP220]', 'BRU Coffee 200GMS [MRP220]', '095', NULL, 215.00, 215.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:46:32', NULL),
(96, 'Sunrise coffee Pouch ', 'Sunrise coffee Pouch ', '096', NULL, 120.00, 120.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(97, 'Sunrise Coffee Jar ', 'Sunrise Coffee Jar ', '097', NULL, 225.00, 225.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(98, 'SS  BRU ', 'SS  BRU ', '098', NULL, 210.00, 210.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(99, 'SS Sunrise 200GMS', 'SS Sunrise 200GMS', '099', NULL, 205.00, 205.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:08:36', NULL),
(100, 'Grren Label Coffee ', 'Grren Label Coffee ', '100', NULL, 108.00, 108.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(101, 'Narasus Coffee 100GMS', 'Narasus Coffee 100GMS', '101', NULL, 80.00, 80.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 09:06:41', NULL),
(102, 'UDhayan narasus coffe', 'உதயம் Narasus Coffee ', '102', NULL, 60.00, 60.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(103, 'sukku coffe thul', 'சுக்கு காபி தூள் ', '103', NULL, 95.00, 95.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(104, 'Mugi Liquid (1 set)MRP430', 'Mugi Liquid (1 set)MRP430', '104', NULL, 400.00, 400.00, 'standard', 'exclusive', 4, 4, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 14:31:56', NULL),
(105, 'Mugi liquid (1+1)MRP230', 'Mugi liquid (1+1)MRP230', '105', NULL, 205.00, 205.00, 'standard', 'exclusive', 4, 4, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 14:34:06', NULL),
(106, 'Mugi Liquid (5 Rs) 1 சரம் ', 'Mugi Liquid (5 Rs) 1 சரம் ', '106', NULL, 45.00, 45.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(107, 'Dettol Liquid 500MIL[MRP235]', 'Dettol Liquid 500MIL[MRP235]', '107', NULL, 230.00, 230.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 10:33:31', NULL),
(108, 'wahing soda', 'வாஷிங் சோடா  ', '108', NULL, 45.00, 45.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(109, 'belicing poweder', 'பிளீச்சிங் பவுடர் ', '109', NULL, 45.00, 45.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(110, 'Comfort Fabric Liquid 1LI[MRP235]', 'Comfort Fabric Liquid 1LI[MRP235]', '110', NULL, 230.00, 230.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 10:41:35', NULL),
(111, 'Lifeboy Soap MRP36', 'Lifeboy Soap (MRP36)', '111', NULL, 35.00, 35.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:12:20', NULL),
(112, 'Hamam Soap [MRP67]', 'Hamam Soap [MRP67]', '112', NULL, 66.00, 66.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:10:34', NULL),
(113, 'Hamam Soap Lemon [MRP42]', 'Hamam Soap Lemon [MRP42]', '113', NULL, 41.00, 41.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 06:11:04', NULL),
(114, 'Lux Soap International ', 'Lux Soap International ', '114', NULL, 39.00, 39.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(115, 'Lux Soap Rose MRP36', 'Lux Soap Rose MRP36', '115', NULL, 35.00, 35.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 07:14:41', NULL),
(116, 'Liril Soap MRP38', 'Liril Soap  MRP38', '116', NULL, 37.00, 37.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 07:14:07', NULL),
(117, 'Rexona Soap ', 'Rexona Soap ', '117', NULL, 37.00, 37.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(118, 'Pears Soap Blue ', 'Pears Soap Blue ', '118', NULL, 49.00, 49.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(119, 'Pears Soap Green ', 'Pears Soap Green ', '119', NULL, 62.00, 62.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(120, 'Pears Soap Yellow ', 'Pears Soap Yellow ', '120', NULL, 53.00, 53.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-03-11 04:15:33', NULL),
(121, 'MS MRP42', 'Mysore Sandal Soap MRP42', '121', NULL, 40.00, 40.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 08:40:38', NULL),
(122, 'CINTHOL MRP50', 'CINTHOL MRP50', '122', NULL, 49.00, 49.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-13 08:39:43', NULL),
(123, 'Santoor Soap Sandal MRP60', 'Santoor Soap Sandal MRP60', '123', NULL, 58.00, 58.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 12:27:29', NULL),
(124, 'Santoor SoapMRP35', 'Santoor Soap  MRP35', '124', NULL, 34.00, 34.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:33', '2024-05-14 12:28:21', NULL),
(125, 'Meera சீவக்காய் தூள் MRP4', 'Meera சீவக்காய் தூள் MRP4', '125', NULL, 56.00, 56.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:16:07', NULL),
(126, 'Karthiga Shampoo ', 'Karthiga Shampoo ', '126', NULL, 18.00, 18.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(127, 'Panteen Shampoo RS2', 'Panteen Shampoo RS2', '127', NULL, 30.00, 30.00, 'standard', 'exclusive', 9, 9, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 15:51:16', NULL),
(128, 'Head&Shoulder Shampoo RS2', 'Head&Shoulder Shampoo RS2', '128', NULL, 38.00, 38.00, 'standard', 'exclusive', 9, 9, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 15:50:55', NULL),
(129, 'Rise Shampoo MRP100', 'Rise Shampoo MRP100', '129', NULL, 90.00, 90.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:38:28', NULL),
(130, 'ali vera sampooo', 'அலோ வேரா ஷாம்பு', '130', NULL, 185.00, 185.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(131, 'Himalaya Baby Shampoo( MRP105)', 'Himalaya Baby Shampoo( MRP105)', '131', NULL, 100.00, 100.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:22:25', NULL),
(132, 'Himalaya Baby Powder  (MRP105)', 'Himalaya Baby Powder  (MRP105)', '132', NULL, 100.00, 100.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:21:53', NULL),
(133, 'Himalaya Baby Soap MRP62', 'Himalaya Baby Soap MRP62', '133', NULL, 58.00, 58.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:23:19', NULL),
(134, 'Himalaya Soap (MRP64)', 'Himalaya Soap (MRP64)', '134', NULL, 60.00, 60.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:24:17', NULL),
(135, 'Himalaya Paste MRP55', 'Himalaya Paste MRP55', '135', NULL, 54.00, 54.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 09:21:16', NULL),
(136, 'Karthika சீவக்காய் தூள் ', 'Karthika சீவக்காய் தூள் ', '136', NULL, 47.00, 47.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(137, 'Chik /shampoo ', 'Chik /shampoo ', '137', NULL, 18.00, 18.00, 'standard', 'exclusive', 9, 9, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:46:03', NULL),
(138, 'Meera Shampoo Badam MRP170', 'Meera Shampoo Badam MRP170', '138', NULL, 165.00, 165.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:46:43', NULL),
(139, 'Meera Shampoo Onion MRP189', 'Meera Shampoo Onion MRP189', '139', NULL, 180.00, 180.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:46:22', NULL),
(140, 'himalaya soap neem', 'அலோ வேரா சோப்பு Yellow ', '140', NULL, 15.00, 15.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(141, 'himalaya soap blue', 'அலோ வேரா சோப்பு Blue ', '141', NULL, 24.00, 24.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(142, 'Chandrika Soap MRP32', 'Chandrika Soap MRP32', '142', NULL, 30.00, 30.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 12:02:05', NULL),
(143, 'Gokul Sandal Soap MRP42', 'Gokul Sandal Soap MRP42', '143', NULL, 40.00, 40.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:27:35', NULL),
(144, 'radhachandam soap', 'ரக்த சந்தன்  ', '144', NULL, 36.00, 36.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(145, 'Medimix Soap ', 'Medimix Soap ', '145', NULL, 48.00, 48.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(146, 'Medimix Soap Sandal ', 'Medimix Soap Sandal ', '146', NULL, 58.00, 58.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(147, 'Dettol Soap Cool  (1 set)', 'Dettol Soap Cool  (1 set)', '147', NULL, 195.00, 195.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:47:24', NULL),
(148, 'Dettol Soap Cool ', 'Dettol Soap Cool ', '148', NULL, 58.00, 58.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(149, 'Dettol Soap Original (1 set )MRP165', 'Dettol Soap Original (1 set )MRP165', '149', NULL, 160.00, 160.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 12:15:57', NULL),
(150, 'Dettol Soap Original ', 'Dettol Soap Original ', '150', NULL, 37.00, 37.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(151, 'Dove Soap White MRP65', 'Dove Soap White MRP65', '151', NULL, 64.00, 64.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 07:44:39', NULL),
(152, 'Dove Soap Pink MRP82', 'Dove Soap Pink MRP82', '152', NULL, 80.00, 80.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 07:45:18', NULL),
(153, 'Dove shampoo MRP180', 'Dove shampoo MRP180', '153', NULL, 175.00, 175.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:47:12', NULL),
(154, 'CLINIC PLUS SAMPOO RS1', 'CLINIC PLUS SAMPOO RS1', '154', NULL, 14.00, 14.00, 'standard', 'exclusive', 9, 9, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:45:45', NULL),
(155, 'C+ Shampoo Jar ', 'C+ Shampoo Jar ', '155', NULL, 180.00, 180.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(156, 'All Clear Shampoo ', 'All Clear Shampoo ', '156', NULL, 28.00, 28.00, 'standard', 'exclusive', 9, 9, 9, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 15:51:30', NULL),
(157, 'Sunsilk Shampoo ', 'Sunsilk Shampoo ', '157', NULL, 130.00, 130.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(158, 'Himalaya Shampoo Antidandruff ', 'Himalaya Shampoo Antidandruff ', '158', NULL, 170.00, 170.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(159, 'Himalaya Shampoo Anti hairfall ', 'Himalaya Shampoo Anti hairfall ', '159', NULL, 155.00, 155.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(160, 'Vim Gel (500MIL) MRP125', 'Vim Gel (500MIL) MRP125', '160', NULL, 120.00, 120.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 07:31:43', NULL),
(161, 'Vim Shudhham Gel MRP60', 'Vim Shudhham Gel MRP60', '161', NULL, 58.00, 58.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 07:28:32', NULL),
(162, 'Vim Soap MRP60', 'Vim Soap MRP60', '162', NULL, 58.00, 58.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 07:29:10', NULL),
(163, 'Exo Soap Round ', 'Exo Soap Round ', '163', NULL, 58.00, 58.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(164, 'jathikkai', 'சாதிக்காய் ', '164', NULL, 1000.00, 1000.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:17:23', NULL),
(165, 'jathipaththiri', 'சாதிபத்ரி ', '165', NULL, 2600.00, 2600.00, 'standard', 'exclusive', 1, 1, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 07:04:14', NULL),
(166, 'elakkai', 'ஏலக்காய் ', '166', NULL, 3000.00, 3000.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:47:38', NULL),
(167, 'annachi poo', 'அண்ணாச்சி பூ ', '167', NULL, 75.00, 75.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(168, 'maraddi', 'மராட்டி ', '168', NULL, 1500.00, 1500.00, 'standard', 'exclusive', 1, 1, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 08:05:29', NULL),
(169, 'passham', 'பாசம் ', '169', NULL, 70.00, 70.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(170, 'brinji ilai', 'பிரிஞ்சி இலை', '170', NULL, 20.00, 20.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(171, 'MUNTHIRI', 'முந்திரி ', '171', NULL, 750.00, 750.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 08:09:16', NULL),
(172, 'badam', 'பாதாம் ', '172', NULL, 800.00, 800.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:45:37', NULL),
(173, 'kismishu', 'கிஸ்மிஸ் ', '173', NULL, 280.00, 280.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(174, 'Black கிஸ்மிஸ் ', 'Black கிஸ்மிஸ் ', '174', NULL, 80.00, 80.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:45:48', NULL),
(175, 'KASAGASA', 'கசகசா ', '175', NULL, 1300.00, 1300.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:58:13', NULL),
(176, 'GIRAMPOO', 'கிராம்பு ', '176', NULL, 1400.00, 1400.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(177, 'PISHA', 'பிஸ்தா ', '177', NULL, 2200.00, 2200.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(178, 'KARUJEERAM', 'கருங்சீரகம் ', '178', NULL, 400.00, 400.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(179, 'SARA POARAVU', 'சாரா பருப்பு', '179', NULL, 1200.00, 1200.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(180, 'PANAM KARGANDU', 'பனங்கற்கண்டு ', '180', NULL, 600.00, 600.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(181, 'KARGANDU', 'கற்கண்டு (Diamond)', '181', NULL, 580.00, 580.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(182, 'AJINA MOTTA', 'அஜினோமோட்டோ', '182', NULL, 180.00, 180.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(183, 'LEMON SALT', 'லெமன் சால்ட் ', '183', NULL, 240.00, 240.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(184, 'Red Colour ', 'Red Colour ', '184', NULL, 28.00, 28.00, 'standard', 'exclusive', 7, 7, 7, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(185, 'Yellow Colour ', 'Yellow Colour ', '185', NULL, 28.00, 28.00, 'standard', 'exclusive', 7, 7, 7, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(186, 'Horlicks (Pouch) MRP220', 'Horlicks (Pouch) MRP220', '186', NULL, 220.00, 220.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 08:37:58', NULL),
(187, 'Horlicks (Jar) MRP294', 'Horlicks (Jar) MRP294', '187', NULL, 280.00, 280.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 08:37:28', NULL),
(188, 'Boost (Pouch) MRP249', 'Boost (Pouch) MRP249', '188', NULL, 240.00, 240.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 08:38:53', NULL),
(189, 'Boost (Jar) MRP299', 'Boost (Jar) MRP299', '189', NULL, 285.00, 285.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 08:38:26', NULL),
(190, 'Bournvita ', 'Bournvita ', '190', NULL, 220.00, 220.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(191, 'meenachi arichi 26KG', 'மீனாட்சி  அரிசி 26KG', '191', NULL, 1650.00, 1650.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:23:13', NULL),
(192, 'thiruvalluvar 26KG', 'திருவள்ளுவர் அரிசி 26KG', '192', NULL, 1720.00, 1720.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 08:17:21', NULL),
(193, 'valluvar dharapuram', 'வள்ளுவர் தாராபுரம் ', '193', NULL, 1820.00, 1820.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(194, '77 Gold ', '77 Gold ', '194', NULL, 1700.00, 1700.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:09:30', NULL),
(195, 'Java அரிசி ', 'Java அரிசி ', '195', NULL, 1700.00, 1700.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:18:55', NULL),
(196, 'goburam arishi', 'கோபுரம் அரிசி ', '196', NULL, 1450.00, 1450.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(197, 'ayyappan arishgi', 'ஐயப்பா அரிசி ', '197', NULL, 1550.00, 1550.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:45:24', NULL),
(198, 'IR 20 அரிசி ', 'IR 20 அரிசி ', '198', NULL, 1150.00, 1150.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(199, 'Lion Dates (Set) ', 'Lion Dates (Set) ', '199', NULL, 185.00, 185.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(200, 'Lion Dates ', 'Lion Dates ', '200', NULL, 58.00, 58.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(201, 'Black Dates ', 'Black Dates ', '201', NULL, 300.00, 300.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(202, 'Lion Dates Syrup ', 'Lion Dates Syrup ', '202', NULL, 195.00, 195.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(203, 'SAFFOLA OATES MRP95', 'SAFFOLA OATES MRP95', '203', NULL, 90.00, 90.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 12:01:41', NULL),
(204, 'Lion Honey (1+1)', 'Lion Honey (1+1)', '204', NULL, 150.00, 150.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(205, 'Lion Honey  MRP58', 'Lion Honey  MRP58', '205', NULL, 56.00, 56.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:30:39', NULL),
(206, 'MTR Gulab Jamun (1+1)', 'MTR Gulab Jamun (1+1)', '206', NULL, 135.00, 135.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 09:11:26', NULL),
(207, 'Nalan Dates MRP130', 'Nalan Dates MRP 130', '207', NULL, 120.00, 120.00, 'standard', 'exclusive', 7, 7, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:22:38', NULL),
(208, 'briyani arishi', 'பிரியாணி அரிசி ', '208', NULL, 97.00, 97.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(209, 'pasumathi arishi', 'பாஸ்மதி அரிசி ', '209', NULL, 120.00, 120.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(210, 'IDLY ARISI KIRSHNA', 'KIRSHNA இட்லி அரிசி ', '210', NULL, 54.00, 54.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 15:05:43', NULL),
(211, 'பொன்னி பச்சரிசி ', 'பொன்னி பச்சரிசி ', '211', NULL, 1430.00, 1430.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(212, 'IR பச்சரிசி ', 'IR பச்சரிசி ', '212', NULL, 40.00, 40.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:58:43', NULL),
(213, 'briyani arishi', 'பிரியாணி அரிசி (Kishan Gold)', '213', NULL, 98.00, 98.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 08:26:45', NULL),
(214, 'Rin Powder MRP118', ' ரின் பவுடர்[MRP118]', '214', NULL, 115.00, 115.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 15:15:23', NULL),
(215, 'Rin Soap MRP25', 'ரின் சோப்[ MRP25]', '215', NULL, 24.00, 24.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 15:17:30', NULL),
(216, 'Rin Liquid Pouch ', 'Rin Liquid Pouch ', '216', NULL, 320.00, 320.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(217, 'Rin Liquid (MRP145)750MIL', 'Rin Liquid (MRP145)750MIL', '217', NULL, 125.00, 125.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:07:18', NULL),
(218, 'Rin Ala ', 'Rin Ala ', '218', NULL, 86.00, 86.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(219, 'Surf XL Easywash Powder ', 'Surf XL Easywash Powder  500gms', '219', NULL, 85.00, 85.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 12:19:55', NULL),
(220, 'Surf XL Powder 1KG MRP220', 'Surf XL Powder 1KG MRP220', '220', NULL, 215.00, 215.00, 'standard', 'exclusive', 4, 4, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:12:22', NULL),
(221, 'Surf XL Soap 250GMS[MRP35]', 'Surf XL Soap 250GMS[MRP35]', '221', NULL, 34.00, 34.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:11:33', NULL),
(222, 'Surf XL Liquid (Jar) Topload MRP190', 'Surf XL Liquid (Jar) Topload  MRP190', '222', NULL, 180.00, 180.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:10:47', NULL),
(223, 'Surf XL Liquid (Pouch)', 'Surf XL Liquid (Pouch)', '223', NULL, 145.00, 145.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(224, 'Surf XL Liquid (Jar) Frontload ', 'Surf XL Liquid (Jar) Frontload ', '224', NULL, 210.00, 210.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(225, 'Surf XL Liquid (Pouch) Frontload ', 'Surf XL Liquid (Pouch) Frontload ', '225', NULL, 160.00, 160.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(226, 'Ariel Powder MRP114', 'ஏரியல் பவுடர் [MRP114]', '226', NULL, 110.00, 110.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 15:14:41', NULL),
(227, 'Ariel Powder Perfect Wash ', 'Ariel Powder Perfect Wash ', '227', NULL, 95.00, 95.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:44:46', NULL),
(228, 'Ariel Liquid Topload  MRP 165', 'Ariel Liquid Topload MRP165', '228', NULL, 160.00, 160.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:53:07', NULL),
(229, 'Ariel Liquid Frontload ', 'Ariel Liquid Frontload ', '229', NULL, 210.00, 210.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(230, 'Ariel Rs.10 Liquid', 'Ariel Rs.10 Liquid', '230', NULL, 10.00, 10.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(231, 'Power Powder MRP102', 'Power Powder MRP102', '231', NULL, 100.00, 100.00, 'standard', 'exclusive', 4, 4, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:14:05', NULL),
(232, 'Power Liquid MRP115', 'Power Liquid  MRP115', '232', NULL, 110.00, 110.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 10:48:43', NULL),
(233, 'Power Liquid Rs.10', 'Power Liquid Rs.10', '233', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(234, 'Power Soap MRP25', 'Power Soap (MRP25)', '234', NULL, 23.00, 23.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 09:11:25', NULL),
(235, 'Nature Power Soap ', 'Nature Power Soap ', '235', NULL, 39.00, 39.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(236, 'Nature Power Soap (PAPAYA)MRP45', 'Nature Power Soap (PAPAYA)MRP45', '236', NULL, 44.00, 44.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 08:31:54', NULL),
(237, 'Tide Powder 1KG( MRP168)', 'Tide Powder 1KG( MRP168)', '237', NULL, 160.00, 160.00, 'standard', 'exclusive', 3, 3, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 05:54:49', NULL),
(238, 'Colgate Tooth Paste 200GMS[MRP130]', 'Colgate Tooth Paste 200GMS[MRP130]', '238', NULL, 125.00, 125.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 11:31:28', NULL);
INSERT INTO `products` (`id`, `name`, `name_ta`, `sku`, `description`, `price`, `cost`, `product_type`, `tax_method`, `unit_id`, `unit_sale_id`, `unit_purchase_id`, `tax`, `category_id`, `supplier_id`, `brand_id`, `created_by`, `minimum_sale_quantity`, `stock_alert`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(239, 'Colgate Paste Salt  200GMS [MRP137]', 'Colgate Paste Salt  200GMS [MRP137]', '239', NULL, 135.00, 135.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 11:30:47', NULL),
(240, 'Colgate Paste [100GMS]MRP69', 'Colgate Paste [100GMS]MRP69', '240', NULL, 68.00, 68.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 06:11:42', NULL),
(241, 'Pepsodent Tooth Paste ', 'Pepsodent Tooth Paste ', '241', NULL, 112.00, 112.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(242, 'CLOSE UP PASTE 100GMS[MRP64]', 'CLOSE UP PASTE 100GMS[MRP64]', '242', NULL, 62.00, 62.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 06:39:13', NULL),
(243, 'DABUR RED PASTE 100GMS[MRP70]', 'DABUR RED PASTE 100GMS[MRP70]', '243', NULL, 68.00, 68.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 09:08:22', NULL),
(244, 'Dabur Meshwak Tooth Paste ', 'Dabur Meshwak Tooth Paste ', '244', NULL, 68.00, 68.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(245, 'SENSODYNE PASTE MRP130', 'SENSODYNE PASTE MRP130', '245', NULL, 125.00, 125.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 15:57:18', NULL),
(246, 'Sensodyne BRUSH [3+1]MRP160', 'Sensodyne BRUSH [3+1]MRP160', '246', NULL, 150.00, 150.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 15:59:35', NULL),
(247, 'Sensodyne BRUSH MRP35', 'Sensodyne BRUSH MRP35', '247', NULL, 30.00, 30.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:56:07', NULL),
(248, 'Sensodyne brush[2+1] MRP130', 'Sensodyne brush[2+1] MRP130', '248', NULL, 120.00, 120.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 15:56:14', NULL),
(249, 'COLGATE BRUSH(SET)MRP70', 'COLGATE BRUSH(SET)MRP70 ', '249', NULL, 65.00, 65.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:55:42', NULL),
(250, 'COLGATE BRUSH MRP30', 'COLGATE BRUSH MRP30', '250', NULL, 28.00, 28.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:54:54', NULL),
(251, 'Exo BRUSH', 'Exo BRUSH', '251', NULL, 9.00, 9.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:54:14', NULL),
(252, 'Exo brush scrubber ', 'Exo brush scrubber ', '252', NULL, 9.00, 9.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-13 06:56:43', NULL),
(253, 'VICCO PASTE [MRP82]100GMS', 'VICCO PASTE [MRP82]100GMS', '253', NULL, 80.00, 80.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 06:33:48', NULL),
(254, 'Vicco பல்பொடி [MRP70]', 'Vicco பல்பொடி [MRP70]', '254', NULL, 68.00, 68.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 06:29:36', NULL),
(255, 'Zandu Balm ', 'Zandu Balm ', '255', NULL, 42.00, 42.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(256, 'Amrutanjan', 'Amrutanjan', '256', NULL, 42.00, 42.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(257, 'Iodex ', 'Iodex ', '257', NULL, 42.00, 42.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(258, 'Vicks ', 'Vicks ', '258', NULL, 98.00, 98.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(259, 'GN Goldflash Liquid Set MRP105', 'GN Goldflash Liquid Set MRP105', '259', NULL, 100.00, 100.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 07:09:21', NULL),
(260, 'GN Goldflash Liquid MRP80', 'GN Goldflash Liquid MRP80', '260', NULL, 77.00, 77.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-05-14 07:08:43', NULL),
(261, 'Good Night Coil ', 'Good Night Coil ', '261', NULL, 38.00, 38.00, 'standard', 'exclusive', 7, 7, 7, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(262, 'All Out Liquid ', 'All Out Liquid ', '262', NULL, 77.00, 77.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(263, 'All Out Liquid Set ', 'All Out Liquid Set ', '263', NULL, 100.00, 100.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(264, 'All Out Liquid ', 'All Out Liquid ', '264', NULL, 77.00, 77.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(265, 'Cycle பத்தி ', 'Cycle பத்தி ', '265', NULL, 50.00, 50.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(266, 'Z Black பத்தி ', 'Z Black பத்தி ', '266', NULL, 50.00, 50.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(267, 'paththi', 'பத்தி ', '267', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(268, 'sudam samll', 'சூடம் (சிறியது)', '268', NULL, 30.00, 30.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:34', '2024-03-11 04:15:34', NULL),
(269, 'sudam periyathiu', 'சூடம் (பெரியது)', '269', NULL, 45.00, 45.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(270, 'sudam', 'சூடம் ', '270', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(271, 'aswini hair oil', 'அஸ்வினி Hairoil ', '271', NULL, 145.00, 145.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(272, 'Super Vasmol Hairoil ', 'Super Vasmol Hairoil ', '272', NULL, 65.00, 65.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(273, 'Vicco Turmeric ', 'Vicco Turmeric ', '273', NULL, 75.00, 75.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(274, 'Moov ', 'Moov ', '274', NULL, 53.00, 53.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(275, 'Gokul Sandal Powder MRP244', 'Gokul Sandal Powder MRP244', '275', NULL, 235.00, 235.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-14 10:37:18', NULL),
(276, 'Nycil Powder (1+1)MRP149', 'Nycil Powder (1+1)MRP149', '276', NULL, 145.00, 145.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 09:44:59', NULL),
(277, 'Ponds Powder Sandal MRP135', 'Ponds Powder Sandal [MRP135]', '277', NULL, 130.00, 130.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 14:35:08', NULL),
(278, 'Ponds Powder MRP110', 'Ponds Powder Dreamflower [MRP110]', '278', NULL, 105.00, 105.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 14:34:42', NULL),
(279, 'Ponds Powder Magic (MRP135)', 'Ponds Powder Magic (MRP135)', '279', NULL, 130.00, 130.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 14:44:18', NULL),
(280, 'Z Powder ', 'Z Powder ', '280', NULL, 135.00, 135.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(281, 'Rusk RS35', 'Rusk RS35', '281', NULL, 35.00, 35.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 09:59:09', NULL),
(282, 'seemiya', 'சேமியா', '282', NULL, 17.00, 17.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 06:50:35', NULL),
(283, 'ragi seemiyya', 'ராகி சேமியா', '283', NULL, 370.00, 370.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(284, 'payasha seemiya', 's பாயசசேமியா ', '284', NULL, 50.00, 50.00, 'standard', 'exclusive', 2, 2, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(285, 'javuarushi 500GMS', 'ஜவ்வரிசி 500GMS', '285', NULL, 50.00, 50.00, 'standard', 'exclusive', 3, 3, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 11:58:18', NULL),
(286, 'sukku', 'சுக்கு ', '286', NULL, 500.00, 500.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(287, 'Milk பிஸ்கட்RS35', 'Milk பிஸ்கட்RS35', '287', NULL, 35.00, 35.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 09:58:19', NULL),
(288, 'Milk Classic  MRP20', 'Milk Classic  MRP20', '288', NULL, 20.00, 20.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-14 13:52:36', NULL),
(289, 'Marie Gold பிஸ்கட்RS 30', 'Marie Gold பிஸ்கட்RS30', '289', NULL, 30.00, 30.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 09:57:16', NULL),
(290, 'Good Day ', 'Good Day ', '290', NULL, 55.00, 55.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(291, '50 50 biscut', '50 - 50 பிஸ்கட் ', '291', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(292, '30 biscut', '30 பிஸ்கட் ', '292', NULL, 30.00, 30.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(293, '40 பிஸ்கட் ', '40 பிஸ்கட் ', '293', NULL, 40.00, 40.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(294, 'Harpic 500MIL (MRP105)', 'Harpic 500MIL (MRP105)', '294', NULL, 103.00, 103.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 07:36:18', NULL),
(295, 'Red Harpic[500MIL] MRP110', 'Red Harpic[500MIL] MRP110', '295', NULL, 105.00, 105.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-14 07:56:51', NULL),
(296, 'Lizol  MRP116', 'Lizol  MRP116', '296', NULL, 114.00, 114.00, 'standard', 'exclusive', 3, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 07:32:52', NULL),
(297, 'pinail', 'பினாயில் ', '297', NULL, 50.00, 50.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(298, 'Acid ', 'Acid ', '298', NULL, 40.00, 40.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(299, 'Colin ', 'Colin ', '299', NULL, 100.00, 100.00, 'standard', 'exclusive', 6, 6, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(300, 'Ujala Crisp and Shine MRP150', 'Ujala Crisp and Shine MRP150', '300', NULL, 145.00, 145.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 07:43:43', NULL),
(301, 'Ujala neelam [MRP80]', 'Ujala நீலம் [MRP80]', '301', NULL, 78.00, 78.00, 'standard', 'exclusive', 4, 4, 6, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 06:18:42', NULL),
(302, 'Fogg Perfume MRP225', 'Fogg Perfume MRP225', '302', NULL, 210.00, 210.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-14 14:33:46', NULL),
(303, 'Fogg Perfume Napoleon', 'Fogg Perfume Napoleon', '303', NULL, 180.00, 180.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(304, 'urugaii 1+1 MRP86', 'ஊறுகாய் (1+1)MRP86', '304', NULL, 85.00, 85.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 12:20:25', NULL),
(305, 'pundu urugai MRP95', 'பூண்டு ஊறுகாய் MRP 95', '305', NULL, 90.00, 90.00, 'standard', 'exclusive', 4, 4, 2, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 12:20:44', NULL),
(306, 'POWER SOAP MRP10', 'POWER SOAP MRP10', '306', NULL, 9.80, 9.80, 'standard', 'exclusive', 4, 4, 1, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 09:13:31', NULL),
(307, 'Maggi நூடுல்ஸ் MRP14', 'Maggi நூடுல்ஸ் MRP14', '307', NULL, 14.00, 14.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 11:55:15', NULL),
(308, 'Maggi நூடுல்ஸ் (8 x 1)MRP112', 'Maggi நூடுல்ஸ் (8 x 1)MRP112', '308', NULL, 110.00, 110.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 11:55:33', NULL),
(309, 'Maggi நூடுல்ஸ் (4 x 1)MRP56', 'Maggi நூடுல்ஸ் (4 x 1)MRP56', '309', NULL, 55.00, 55.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 11:55:55', NULL),
(310, 'Yippee நூடுல்ஸ்  MRP14', 'Yippee நூடுல்ஸ்  MRP14', '310', NULL, 14.00, 14.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 11:56:11', NULL),
(311, 'Yippee நூடுல்ஸ் (4 x 1)MRP56', 'Yippee நூடுல்ஸ் (4 x 1)MRP56', '311', NULL, 55.00, 55.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-05-13 11:56:36', NULL),
(312, 'vv thegaiennai', 'விவி தேங்காய் எண்ணெய் ', '312', NULL, 0.00, 0.00, 'standard', 'exclusive', NULL, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(313, 'test', 'test ta', '313', NULL, 1.00, 1.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, NULL, NULL, '2024-03-11 04:15:35', '2024-03-11 04:15:35', NULL),
(314, 'SAKTHI MELAGAI THUL', 'சக்தி மிளகாய் தூள் ', '1100', NULL, 300.00, 300.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:17:26', '2024-05-13 05:17:26', NULL),
(315, 'Java அரிசி  10kg', 'Java அரிசி 10kg', '1101', NULL, 740.00, 740.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:20:03', '2024-05-13 05:20:03', NULL),
(316, 'Java அரிசி 5kg', 'Java அரிசி 5kg', '1102', NULL, 370.00, 370.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:20:43', '2024-05-13 05:20:43', NULL),
(317, 'pattai', 'பட்டை ', '1103', NULL, 280.00, 280.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:21:40', '2024-05-13 06:19:03', NULL),
(318, '3ROSE TEA 100GMS', 'திரி ரோஸஸ் டீ தூள்100GMS', '1104', NULL, 88.00, 88.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:29:31', '2024-05-13 05:29:31', NULL),
(319, '3ROSE TEA 250GMS[220]', 'திரி ரோஸஸ் டீ தூள் 250GMS[220]', '1105', NULL, 215.00, 215.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:30:43', '2024-05-13 06:50:52', NULL),
(320, 'gw 1li', 'GOLD WINNER 1LI', '1106', NULL, 112.00, 112.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:31:38', '2024-05-13 05:31:38', NULL),
(321, 'SF', 'SUN FLOWER OIL', '1107', NULL, 110.00, 110.00, 'standard', 'exclusive', 5, 5, 5, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:32:13', '2024-05-13 05:32:13', NULL),
(322, 'SAKTHI SAMBER THUL', 'சக்தி சாம்பார் தூள்', '1108', NULL, 340.00, 340.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:34:31', '2024-05-13 05:34:31', NULL),
(323, 'CHIKKAN MASALA 100GMS', 'சக்தி சிக்கன் மசாலா 100GMS', '1109', NULL, 34.00, 34.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:36:25', '2024-05-13 06:19:27', NULL),
(324, 'சக்தி சிக்கன் மசாலா 50GMS', 'சக்தி சிக்கன் மசாலா 50GMS', '1110', NULL, 17.00, 17.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:36:57', '2024-05-13 05:36:57', NULL),
(325, 'SAKTHI MALLI THUL', 'சக்தி மல்லி தூள் ', '1112', NULL, 200.00, 200.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:40:50', '2024-05-13 05:40:50', NULL),
(326, 'SAKTHI MALLI THUL 100GMS', 'சக்தி மல்லி தூள் 100gms', '1113', NULL, 20.00, 20.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:41:46', '2024-05-13 05:41:46', NULL),
(327, 'SAKTHI MALLI THUL', 'சக்தி மல்லி தூள் 50GMS', '1114', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:43:16', '2024-05-13 05:43:16', NULL),
(328, 'GOTHUMAI MAVU 1KG', 'கோதுமை மாவு  1KG', '1115', NULL, 60.00, 60.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:50:51', '2024-05-13 05:50:51', NULL),
(329, 'GOTHUMAI MAVU 500GMS', 'கோதுமை மாவு  500GMS', '1116', NULL, 32.00, 32.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:51:31', '2024-05-13 05:51:31', NULL),
(330, 'Tide Powder 500GMS (MRP84)', 'Tide Powder 500GMS (MRP84)', '1117', NULL, 80.00, 80.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 05:56:13', '2024-05-13 05:56:13', NULL),
(331, 'IDHAYAM NALLA ENNAI  200MIL(MRP89)', 'இதயம் நல்லெண்ணெய்200MIL(MRP89)', '1118', NULL, 85.00, 85.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:00:41', '2024-05-14 09:32:56', NULL),
(332, 'IDHAYA NALLA ENNAI 100MIL (MRP50)', 'இதயம் நல்லெண்ணெய் 100MIL (MRP50)', '1119', NULL, 45.00, 45.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:03:50', '2024-05-13 06:03:50', NULL),
(333, 'GHEE 500MIL', 'நெய் 500MIL', '1120', NULL, 350.00, 350.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:05:09', '2024-05-13 06:05:09', NULL),
(334, 'GHEE 100MIL', 'நெய்  100MIL', '1121', NULL, 75.00, 75.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:05:39', '2024-05-13 06:05:39', NULL),
(335, 'GHEE 50MIL', 'நெய் 50MIL', '1122', NULL, 40.00, 40.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:06:06', '2024-05-13 06:06:06', NULL),
(336, 'HAMAM SOAP[MRP41]', 'HAMAM SOAP[MRP41]', '1123', NULL, 40.00, 40.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:11:48', '2024-05-13 06:11:48', NULL),
(337, 'VANASPATHI 500MIL', 'டால்டா 500MIL', '1125', NULL, 58.00, 58.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:14:16', '2024-05-13 06:14:16', NULL),
(338, 'Karthika சீவக்காய் தூள் RS2', 'Karthika சீவக்காய் தூள் RS2', '1126', NULL, 38.00, 38.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:15:33', '2024-05-13 06:15:33', NULL),
(339, 'MEENATCHI ARISI ', 'மீனாட்சி  அரிசி ', '1127', NULL, 68.00, 68.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:24:11', '2024-05-13 06:24:11', NULL),
(340, 'THEAN SITTU ARISI 10KG', 'தேன் சிட்டு  அரிசி10KG', '1128', NULL, 720.00, 720.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:28:38', '2024-05-13 06:28:38', NULL),
(341, 'THEAN SITTU 5KG', ' தேன் சிட்டு அரிசி 5KG', '1129', NULL, 360.00, 360.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:29:39', '2024-05-13 06:29:39', NULL),
(342, 'THEAN SITTUI ARISI 26KG', 'தேன் சிட்டு 26KG', '1130', NULL, 1720.00, 1720.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:30:30', '2024-05-13 06:30:30', NULL),
(343, 'SEENI', 'சீனி', '1131', NULL, 43.00, 43.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:31:25', '2024-05-13 06:31:25', NULL),
(344, 'TATA SALT', 'TATA SALT', '1132', NULL, 27.00, 27.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:32:01', '2024-05-13 06:32:01', NULL),
(345, 'TATA  கல் உப்பு', ' TATA கல் உப்பு', '1133', NULL, 18.00, 18.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:33:02', '2024-05-13 06:33:02', NULL),
(346, 'KAL UPPU', 'கஸ்தூரி கல் உப்பு', '1134', NULL, 10.00, 10.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:33:27', '2024-05-14 13:41:52', NULL),
(347, 'SALT மகிழ்ச்சி  500GMS', ' மகிழ்ச்சி SALT  500GMS', '1135', NULL, 5.00, 5.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:34:06', '2024-05-14 13:36:02', NULL),
(348, 'APPALAM 100GMS', ' அப்பளம் 100GMS', '1136', NULL, 20.00, 20.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:37:13', '2024-05-13 06:37:13', NULL),
(349, 'APPALAM 200GMS', ' அப்பளம்200GMS', '1137', NULL, 40.00, 40.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:38:40', '2024-05-13 06:38:40', NULL),
(350, 'APPALAM 150GMS', ' அப்பளம்150GMS', '1138', NULL, 30.00, 30.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:39:06', '2024-05-13 06:39:06', NULL),
(351, 'PATTAI GIRAMPOO RS50', 'ப.கி RS50', '1139', NULL, 50.00, 50.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:41:22', '2024-05-13 06:41:22', NULL),
(352, 'PATTAI GIRAPOO RS100', 'ப.கி RS100', '1140', NULL, 100.00, 100.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:42:15', '2024-05-13 06:42:15', NULL),
(353, 'PATTAI GIRAMPOO', 'ப.கி RS10', '1141', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:42:41', '2024-05-13 06:42:41', NULL),
(354, 'SABINA 500GMS', 'சபீனா 500GMS', '1142', NULL, 15.00, 15.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:46:58', '2024-05-13 06:46:58', NULL),
(355, 'SAKTHI BRIYANI MASALA 50GMS', 'சக்தி பிரியாணி மசாலா 50GMS', '1143', NULL, 26.00, 26.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:49:27', '2024-05-13 06:49:27', NULL),
(356, '3ROSE NC 100GMS (MRP100)', 'திரி ரோஸஸ் டீ NaturalCare 250GMS (MRP240)', '1144', NULL, 98.00, 98.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 06:53:34', '2024-05-13 06:53:34', NULL),
(357, 'PONNI PACHCHAI ARISI', 'பொன்னி பச்சரிசி ', '1146', NULL, 68.00, 68.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:00:52', '2024-05-14 09:35:00', NULL),
(358, 'TAJ MAHAL TEA 100GMS(MRP95)', 'TAJ MAHAL TEA 100GMS(MRP95)', '1147', NULL, 93.00, 93.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:05:14', '2024-05-13 07:05:14', NULL),
(359, 'VIM SOAP MRP10', 'VIM SOAP MRP10', '1148', NULL, 9.80, 9.80, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:25:54', '2024-05-13 07:25:54', NULL),
(360, 'VIM MRP5', 'VIM MRP5', '1149', NULL, 4.90, 4.90, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:26:30', '2024-05-13 07:26:30', NULL),
(361, 'VIM SOAP MRP30', 'VIM SOAP MRP30', '1150', NULL, 29.00, 29.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:27:02', '2024-05-13 07:27:02', NULL),
(362, 'VIM GEL MRP15', 'VIM GEL MRP15', '1151', NULL, 15.00, 15.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:29:46', '2024-05-13 07:29:46', NULL),
(363, 'VIM GEL MRP89', 'VIM GEL MRP89', '1152', NULL, 85.00, 85.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:30:23', '2024-05-13 07:30:23', NULL),
(364, 'VIM GEL 250MIL (MRP55)', 'VIM GEL 250MIL (MRP55)', '1153', NULL, 53.00, 53.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:31:21', '2024-05-13 07:31:21', NULL),
(365, 'LIZOL 200MIL (MRP45)', 'LIZOL 200MIL (MRP45)', '1154', NULL, 44.00, 44.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:35:18', '2024-05-13 07:35:18', NULL),
(366, 'KUNDU MANJAL ', 'குண்டு மஞ்சள்', '1155', NULL, 280.00, 280.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:47:24', '2024-05-13 07:47:24', NULL),
(367, 'VIRALY MANJAL', 'விரலி மஞ்சள்', '1156', NULL, 280.00, 280.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:48:52', '2024-05-13 07:48:52', NULL),
(368, 'ELAKKAI ', 'ஏலக்காய்', '1157', NULL, 2900.00, 2900.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:56:56', '2024-05-13 07:56:56', NULL),
(369, 'ELAKKAI 10GMS', 'ஏலக்காய்10GMS', '1158', NULL, 30.00, 30.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 07:59:10', '2024-05-13 07:59:10', NULL),
(370, 'NIRMA 1KG MRP64', ' நிர்மா 1KG MRP64', '1159', NULL, 62.00, 62.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:01:57', '2024-05-13 08:01:57', NULL),
(371, 'NIRAMA 500GMS(MRP32)', ' நிர்மா500GMS(MRP32)', '1160', NULL, 30.00, 30.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:03:26', '2024-05-13 08:03:26', NULL),
(372, 'THIRUVALLUVAR ARISI 10KG', 'திருவள்ளுவர் அரிசி 10KG', '1162', NULL, 760.00, 760.00, 'standard', 'exclusive', 8, 8, 8, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:16:05', '2024-05-13 08:16:05', NULL),
(373, 'THIRUVALLUVAR ARISI', 'திருவள்ளுவர் அரிசி 5KG', '1163', NULL, 380.00, 380.00, 'standard', 'exclusive', 8, NULL, 8, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:16:46', '2024-05-13 08:16:46', NULL),
(374, 'SAKTHI BAJJI MAVU 200GMS', 'சக்தி பஜ்ஜி மாவு  200GMS', '1164', NULL, 28.00, 28.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:22:08', '2024-05-13 12:03:17', NULL),
(375, 'CORN MAVU 200GMS', 'காண் மாவு 200GMS', '1166', NULL, 20.00, 20.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:25:31', '2024-05-13 08:25:31', NULL),
(376, 'MID MIX SOAP MRP49', 'MID MIX SOAP MRP49', '1167', NULL, 48.00, 48.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:29:37', '2024-05-13 08:29:37', NULL),
(377, 'MIDMIX SOAP MRP32', 'MIDMIX SOAP MRP32', '1168', NULL, 31.00, 31.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:30:26', '2024-05-13 08:30:26', NULL),
(378, 'MS MRP82', 'MS SOAP MRP82', '1169', NULL, 80.00, 80.00, 'standard', 'exclusive', 4, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:41:54', '2024-05-13 08:41:54', NULL),
(379, 'MS SOAP MRP69', 'MS SOAP MRP69', '1170', NULL, 68.00, 68.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:42:20', '2024-05-13 08:42:20', NULL),
(380, 'CINTHOL SOAP MRP75', 'CINTHOL SOAP MRP75', '1171', NULL, 73.00, 73.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:43:20', '2024-05-13 08:43:20', NULL),
(381, 'BOOST 200GMS  MRP114', 'BOOST 200GMS  MRP114', '1165', NULL, 110.00, 110.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:55:57', '2024-05-13 08:55:57', NULL),
(382, 'BOOST JAR200GMS (MRP139)', 'BOOST JAR200GMS (MRP139)', '1175', NULL, 130.00, 130.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:57:14', '2024-05-13 08:57:14', NULL),
(383, 'HORLICKS 200GMS MRP115', 'HORLICKS 200GMS MRP115', '1176', NULL, 112.00, 112.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:58:29', '2024-05-13 08:58:29', NULL),
(384, 'HORLICKS 200GMS MRP134(JAR)', 'HORLICKS 200GMS MRP134(JAR)', '1177', NULL, 130.00, 130.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 08:59:37', '2024-05-13 08:59:37', NULL),
(385, 'HATSUN CURD RS25', 'HATSUN தயிர்RS25', '1178', NULL, 25.00, 25.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:00:58', '2024-05-13 09:00:58', NULL),
(386, 'HATSUN CURD RS50', 'HATSUN தயிர்RS50', '1179', NULL, 50.00, 50.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:01:31', '2024-05-13 09:01:31', NULL),
(387, 'MUTTAI RS6.70', 'முட்டை', '1180', NULL, 6.70, 6.70, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:02:14', '2024-05-13 09:02:14', NULL),
(388, 'PATHTHI MRP55', 'பத்தி MRP55', '1172', NULL, 50.00, 50.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:03:40', '2024-05-13 09:03:40', NULL),
(389, 'PATHTHI MRP50', 'பத்தி MRP50', '1173', NULL, 45.00, 45.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:04:07', '2024-05-13 09:04:07', NULL),
(390, 'PATHTHI MRP25', 'பத்தி MRP25', '1174', NULL, 20.00, 20.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:04:39', '2024-05-13 09:04:39', NULL),
(391, 'ROJA COFEE 100GMS', 'ரோஜா காப்பி தூள்100MS', '1182', NULL, 35.00, 35.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:06:06', '2024-05-13 09:06:06', NULL),
(392, 'NARASUS COFEE 50GMS', 'NARASUS COFEE 50GMS', '1181', NULL, 40.00, 40.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:07:46', '2024-05-13 09:07:46', NULL),
(393, 'SUNRISE COFEE 200GMS(MRP170)', 'SUNRISE COFEE 200GMS(MRP170', '1183', NULL, 165.00, 165.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:09:25', '2024-05-13 09:09:25', NULL),
(394, 'GW 500MIL', 'GW 500MIL', '1184', NULL, 60.00, 60.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:09:58', '2024-05-13 09:09:58', NULL),
(395, 'SF 500MIL', 'SF 500MIL', '1185', NULL, 60.00, 60.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:10:24', '2024-05-13 09:10:24', NULL),
(396, 'POWER POWDER 500GMS MRP52', 'POWER POWDER 500GMS (MRP52)', '1186', NULL, 50.00, 50.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:16:01', '2024-05-13 09:16:01', NULL),
(397, 'sakthi idly podi 50gms', 'சக்தி இட்லி பொடி 50gms', '1187', NULL, 15.00, 15.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:19:43', '2024-05-13 09:19:43', NULL),
(398, 'NATTU KOZHI MASALA 50GMS', 'நாட்டு கோழி மசாலா50GMS', '1188', NULL, 22.00, 22.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:20:54', '2024-05-13 09:20:54', NULL),
(399, 'THIPETTI', 'தீப்பெட்டி', '1189', NULL, 10.00, 10.00, 'standard', 'exclusive', 7, 7, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:30:08', '2024-05-13 09:30:08', NULL),
(400, 'BRU RS2', 'BRU RS2', '1190', NULL, 22.00, 22.00, 'standard', 'exclusive', 9, 9, 9, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:49:11', '2024-05-14 09:32:01', NULL),
(401, 'SUNRISE COFEE RS2', 'SUNRISE COFEE RS2', '1191', NULL, 22.00, 22.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:49:40', '2024-05-13 09:49:40', NULL),
(402, 'BRU RS10', 'BRU RS10', '1192', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:50:07', '2024-05-13 09:50:07', NULL),
(403, 'SUNRISE MRP10', 'SUNRISE MRP10', '1193', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:50:48', '2024-05-13 09:50:48', NULL),
(404, 'BOOST RS5', 'BOOST RS5', '1197', NULL, 73.00, 73.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:51:53', '2024-05-13 09:51:53', NULL),
(405, 'boost RS5', 'boost RS5', '1198', NULL, 5.00, 5.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:54:20', '2024-05-13 09:54:20', NULL),
(406, 'HORLICKS RS5', 'HORLICKS RS5', '1199', NULL, 58.00, 58.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:55:10', '2024-05-13 09:55:10', NULL),
(407, 'HORLICKS RS5', 'HORLICKS RS5', '1200', NULL, 5.00, 5.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:55:39', '2024-05-13 09:55:39', NULL),
(408, 'Marie Gold பிஸ்கட்RS30', 'Marie Gold பிஸ்கட்RS30', '1201', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:57:34', '2024-05-13 09:57:34', NULL),
(409, 'Milk பிஸ்கட்RS10', 'Milk பிஸ்கட்RS10', '1202', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:58:43', '2024-05-13 09:58:43', NULL),
(410, 'RUSK RS10', 'RUSK RS10', '1204', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 09:59:46', '2024-05-13 09:59:46', NULL),
(411, 'KUNGUNAM RS15', 'குங்குமம் RS15', '1205', NULL, 15.00, 15.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:04:55', '2024-05-13 10:04:55', NULL),
(412, 'SANDHANAM RS15', 'சந்தானம் RS25', '1206', NULL, 20.00, 20.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:06:08', '2024-05-13 10:06:08', NULL),
(413, 'VIPOOTHI RS15', ' விபூதி RS15', '1207', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:06:51', '2024-05-13 10:06:51', NULL),
(414, 'TEA CUP', 'TEA CUP', '1208', NULL, 45.00, 45.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:10:50', '2024-05-13 10:10:50', NULL),
(415, 'WATER CUP', 'WATER CUP', '1209', NULL, 65.00, 65.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:11:23', '2024-05-13 10:11:23', NULL),
(416, 'PAPER ROLE ', 'PAPER ROLE', '1210', NULL, 90.00, 90.00, 'standard', 'exclusive', 4, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:11:59', '2024-05-13 10:11:59', NULL),
(417, 'CHEKKU THEGAI ENNAI 200MIL', 'செக்கு தேங்காய் எண்ணெய் 200MIL ', '1211', NULL, 50.00, 50.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:16:43', '2024-05-13 10:16:43', NULL),
(418, 'VVD 100MIL', 'VVD 100MIL', '1212', NULL, 25.00, 25.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:17:12', '2024-05-13 10:17:12', NULL),
(419, 'chekku velakku ennai 100MIL', 'செக்கு விளக்கெண்ணெய் 100MIL', '1213', NULL, 20.00, 20.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:18:53', '2024-05-13 10:18:53', NULL),
(420, 'VVD 100MIL JAR', 'VVD 100MIL JAR', '1214', NULL, 30.00, 30.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:19:25', '2024-05-13 10:19:25', NULL),
(421, 'CHOCOLATE MRP120', ' சாக்லேட் MRP120', '1215', NULL, 115.00, 115.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 10:20:28', '2024-05-13 10:20:28', NULL),
(422, 'LG KATTI 50GMS', 'LG.பெருகாயம் கட்டி 50GMS', '1220', NULL, 70.00, 70.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 11:48:39', '2024-05-13 11:48:39', NULL),
(423, 'LG THUL 50GMS', 'LG.பெருகாயம் தூள் 50GMS', '1219', NULL, 70.00, 70.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 11:49:51', '2024-05-13 11:49:51', NULL),
(424, 'LG.THUL 100GMS', 'LG.பெருகாயம் தூள் 100GMS', '1218', NULL, 138.00, 138.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 11:50:33', '2024-05-13 11:50:33', NULL),
(425, 'LG KATTI 100GMS', 'LG.பெருகாயம் கட்டி 100GMS', '1217', NULL, 138.00, 138.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 11:51:40', '2024-05-13 11:51:40', NULL),
(426, 'AACHI KULAMPU MASALA', 'ஆச்சி குழம்பு மிளகாய் தூள்', '1216', NULL, 330.00, 330.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 11:53:22', '2024-05-13 11:53:22', NULL),
(427, 'FAB LIQ MRP99', 'FAB LQ[MRP99]', '1221', NULL, 95.00, 95.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 11:54:15', '2024-05-13 11:54:15', NULL),
(428, 'PAYASHA SEEMIYA', 's பாயசசேமியா ', '1223', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 11:57:42', '2024-05-13 11:57:42', NULL),
(429, 'JAVUARISI 200GMS', 'ஜவ்வரிசி 200GMS', '1225', NULL, 20.00, 20.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:00:03', '2024-05-13 12:00:03', NULL),
(430, 'COLGATE SALT [100GMS]MRP76', 'COLGATE SALT [100GMS]MRP76', '1226', NULL, 74.00, 74.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:08:08', '2024-05-14 06:12:05', NULL),
(431, 'RB SODA 100GMS', 'RB சோடா 100GMS', '1227', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:09:22', '2024-05-13 12:09:22', NULL),
(432, 'AVT TEA 250GMS[MRP100]', 'ஏவிடி டீ 250GMS[MRP100]', '1229', NULL, 95.00, 95.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:11:35', '2024-05-13 12:11:35', NULL),
(433, 'AVT TEA RS40', 'ஏவிடி டீ 100GMS [MRP40]', '1230', NULL, 38.00, 38.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:12:22', '2024-05-13 12:12:22', NULL),
(434, '3ROSE RS10', '3ROSE TEA RS10', '1228', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, 3, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:14:44', '2024-05-13 12:14:44', NULL),
(435, 'ARUNA SAMBER THUL 200GMS', ' அருணா சாம்பர் தூள் 200GMS', '1232', NULL, 65.00, 65.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:18:20', '2024-05-13 12:18:20', NULL),
(436, 'URUGAI ', '  ஊறுகாய்', '1233', NULL, 200.00, 200.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:22:17', '2024-05-13 12:22:17', NULL),
(437, 'PUNDU ', 'நயம் பூண்டு', '1235', NULL, 400.00, 400.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:23:20', '2024-05-13 12:23:20', NULL),
(438, 'GHEE UDHAYA 100MIL', ' உதய கிருஷண நெய் 100MIL', '1236', NULL, 80.00, 80.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:25:27', '2024-05-13 12:25:27', NULL),
(439, 'UDHAYA KIRSHNA GHEE 200MILL', ' உதய கிருஷண நெய் 200MIL', '1240', NULL, 155.00, 155.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:27:19', '2024-05-13 12:27:19', NULL),
(440, 'UDHAYA KIRSHNA GHEE 500MIL', ' உதய கிருஷண நெய் 500MILL', '1239', NULL, 380.00, 380.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:27:59', '2024-05-13 12:27:59', NULL),
(441, 'VALLUVAR ARISI', 'வள்ளுவர்  அரிசி', '1238', NULL, 75.00, 75.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:32:30', '2024-05-13 12:32:30', NULL),
(442, 'ARISI 68', 'சாப்பாடு  அரிசி', '1241', NULL, 68.00, 68.00, 'standard', 'exclusive', 1, 1, 1, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 12:36:17', '2024-05-13 12:36:17', NULL),
(443, 'PONDS MAGIC MRP72', 'PONDS MAGIC[ MRP72]', '1250', NULL, 70.00, 70.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 14:45:07', '2024-05-13 14:45:07', NULL),
(444, 'PONDS SANDAL MRP72', 'PONDS SANDAL MRP72', '1249', NULL, 70.00, 70.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:01:48', '2024-05-13 15:01:48', NULL),
(445, 'PONDS RS10', 'PONDS RS10', '1248', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:02:33', '2024-05-13 15:02:33', NULL),
(446, 'VSN BLK அரிசி 26KG', 'VSN BLK அரிசி 26KG', '1247', NULL, 1800.00, 1800.00, 'standard', 'exclusive', 8, 8, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:05:10', '2024-05-13 15:05:10', NULL),
(447, 'KIRSHNA இட்லி அரிசி  TAMILAN 26KG', 'KIRSHNA இட்லி அரிசி[ TAMILAN]26KG', '1246', NULL, 1250.00, 1250.00, 'standard', 'exclusive', 8, 8, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:06:39', '2024-05-13 15:06:39', NULL),
(448, 'BATTERY MRP18', 'BATTERY MRP18', '1245', NULL, 15.00, 15.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:16:56', '2024-05-13 15:16:56', NULL),
(449, 'VENUS 1KG', ' வீனஸ் 1KG', '1251', NULL, 30.00, 30.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:36:38', '2024-05-13 15:36:38', NULL),
(450, 'UDHAYAM DEEPAM ENNAI 100MIL', 'உதயம் தீபம் எண்ணெய் 100MIL', '1242', NULL, 20.00, 20.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:39:53', '2024-05-13 15:39:53', NULL),
(451, 'SUNSLIK SAMPOO RS1', 'SUNSLIK SAMPOO RS1', '1252', NULL, 14.00, 14.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 15:53:13', '2024-05-13 15:53:13', NULL),
(452, 'ELLU ', 'எள்ளு', '1255', NULL, 300.00, 300.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 16:02:43', '2024-05-13 16:02:43', NULL),
(453, 'KISSAN JAM RS20', 'KISSAN JAM RS20', '1260', NULL, 20.00, 20.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-13 16:03:25', '2024-05-13 16:03:25', NULL),
(454, 'VICCO PAL PODI MRP 115', 'VICCOபல் பொடி [MRP115]', '1300', NULL, 110.00, 110.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:27:44', '2024-05-14 06:27:44', NULL),
(455, 'Vicco பல்பொடி [MRP40]', 'Vicco பல்பொடி [MRP40]', '1299', NULL, 38.00, 38.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:30:07', '2024-05-14 06:30:07', NULL),
(456, 'VICCOPASTE [MRP46]', 'VICCO PASTEMRP46]', '1298', NULL, 44.00, 44.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:36:06', '2024-05-14 06:36:06', NULL),
(457, 'CLOSE UP PASTE 150GMS[MRP118]', 'CLOSE UP PASTE 150GMS[MRP118]', '1297', NULL, 115.00, 115.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:40:34', '2024-05-14 06:40:34', NULL),
(458, 'CLOSE UP PASTE[MRP20]', 'CLOSE UP PASTE[MRP20]', '1296', NULL, 19.00, 19.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:44:36', '2024-05-14 06:44:36', NULL),
(459, 'KP நம்பூதிரி PASTE[MRP60] 100GMS', 'KP நம்பூதிரி PASTE[MRP60] 100GMS', '1295', NULL, 58.00, 58.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:47:21', '2024-05-14 06:47:21', NULL),
(460, 'KP நம்பூதிரி PASTE[MRP20] 50GMS', 'KP நம்பூதிரி PASTE[MRP20] 50GMS', '1294', NULL, 19.00, 19.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:47:54', '2024-05-14 06:47:54', NULL),
(461, 'KP நம்பூதிரி பல் பொடி[MRP35]', 'KP நம்பூதிரி பல் பொடி[MRP35]', '1293', NULL, 34.00, 34.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:50:29', '2024-05-14 06:50:29', NULL),
(462, 'KP நம்பூதிரி பல் பொடி[MRP55]', 'KP நம்பூதிரி பல் பொடி[MRP55]', '1292', NULL, 53.00, 53.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:50:58', '2024-05-14 06:50:58', NULL),
(463, 'KASTHURI MANJAL MRP30', 'கஸ்தூரி மஞ்சள் MRP30', '1291', NULL, 25.00, 25.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:52:38', '2024-05-14 06:52:38', NULL),
(464, 'LOTUS SAMBARANI RS22', 'LOTUS சாம்பிராணி [RS22]', '1290', NULL, 15.00, 15.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:55:53', '2024-05-14 06:57:04', NULL),
(465, 'LOTUS CUP சாம்பிராணி [RS90]', 'LOTUS CUP சாம்பிராணி [RS90]', '1289', NULL, 70.00, 70.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 06:59:37', '2024-05-14 06:59:37', NULL),
(466, 'LOTUS கட்டிசாம்பிராணி [RS40]', 'LOTUS கட்டிசாம்பிராணி [RS40]', '1288', NULL, 25.00, 25.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:01:33', '2024-05-14 07:01:33', NULL),
(467, 'CUP SAMBRANI NAVIN RS72', 'CUP SAMBRANI NAVIN RS72', '1287', NULL, 55.00, 55.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:02:33', '2024-05-14 07:02:33', NULL),
(468, 'MANGAL DEEP SAMBARANI MRP72', 'MANGAL DEEP SAMBARANI MRP72', '1286', NULL, 55.00, 55.00, 'standard', 'exclusive', 4, NULL, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:03:20', '2024-05-14 07:03:20', NULL),
(469, 'MANGALDEEP PATHTHI MRP50', 'மங்கல்தீப் பத்தி MRP50', '1285', NULL, 45.00, 45.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:06:32', '2024-05-14 07:06:32', NULL),
(470, 'JM பல் பொடிMRP40', 'JM பல் பொடிMRP40', '1284', NULL, 35.00, 35.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:12:49', '2024-05-14 07:12:49', NULL),
(471, 'MARGO SOAP MRP45', 'MARGO SOAP MRP45', '1283', NULL, 43.00, 43.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:20:50', '2024-05-14 07:20:50', NULL),
(472, 'Red Harpic 200mil[MRP49]', 'Red Harpic 200mil[MRP49]', '1282', NULL, 46.00, 46.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:56:09', '2024-05-14 07:56:09', NULL),
(473, 'Harpic 200mil[MRP44]', 'Harpic 200mil[MRP44]', '1280', NULL, 42.00, 42.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:57:44', '2024-05-14 07:57:44', NULL),
(474, 'POOJA OIL 1LI', 'POOJA OIL 1LI', '1279', NULL, 175.00, 175.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 07:59:43', '2024-05-14 07:59:43', NULL),
(475, 'CURD RS10', ' தயிர் RS10', '1278', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:00:41', '2024-05-14 09:33:08', NULL),
(476, 'OMAM', ' ஓமம்', '1281', NULL, 400.00, 400.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:03:13', '2024-05-14 08:03:13', NULL),
(477, 'KISMISH', 'கிஸ்மிஸ் ', '1277', NULL, 300.00, 300.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:06:59', '2024-05-14 08:06:59', NULL),
(478, 'MUNTHIRI', ' முந்திரி', '1276', NULL, 730.00, 730.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:08:47', '2024-05-14 08:08:47', NULL);
INSERT INTO `products` (`id`, `name`, `name_ta`, `sku`, `description`, `price`, `cost`, `product_type`, `tax_method`, `unit_id`, `unit_sale_id`, `unit_purchase_id`, `tax`, `category_id`, `supplier_id`, `brand_id`, `created_by`, `minimum_sale_quantity`, `stock_alert`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(479, 'BRIYANI ARISI', 'பிரியாணி அரிசி (Kishan Gold)', '1275', NULL, 95.00, 95.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:27:25', '2024-05-14 08:27:25', NULL),
(480, 'MEERA ONION SAPMPOO RS2', 'MEERA ONION SAPMPOO RS2', '1272', NULL, 38.00, 38.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:29:31', '2024-05-14 08:29:31', NULL),
(481, 'MEERA BADAM SAMPOO RS2', 'MEERA BADAM SAMPOO RS2', '1301', NULL, 38.00, 38.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:31:21', '2024-05-14 08:31:21', NULL),
(482, 'SUNSLIK SAMPOO MRP135', 'SUNSLIK SAMPOO MRP135', '1302', NULL, 130.00, 130.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 08:34:18', '2024-05-14 08:34:18', NULL),
(483, 'EVREST GARAM MASALA 100GMS', 'EVREST GARAM MASALA 100GMS', '1304', NULL, 85.00, 85.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:04:39', '2024-05-14 09:04:39', NULL),
(484, '3ROSE TEA 50GMS[MRP45]', '3ROSE TEA 50GMS[MRP45]', '1305', NULL, 43.00, 43.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:07:06', '2024-05-14 09:07:06', NULL),
(485, 'DABUR RED PASTE 200GMS[MRP130]', 'DABUR RED PASTE 200GMS[MRP130]', '1306', NULL, 128.00, 128.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:09:57', '2024-05-14 09:09:57', NULL),
(486, 'DABUR RED PASTE 50GMS[MRP20]', 'DABUR RED PASTE 50GMS[MRP20]', '1307', NULL, 19.00, 19.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:10:27', '2024-05-14 09:10:27', NULL),
(487, 'EYETEX PATHTHI[MRP12]', 'EYETEX பத்தி [MRP12]', '1308', NULL, 10.00, 10.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:14:54', '2024-05-14 09:14:54', NULL),
(488, 'VIP HAIR CLR MRP52', 'VIP HAIR CLR MRP52', '1309', NULL, 50.00, 50.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:16:56', '2024-05-14 09:16:56', NULL),
(489, 'INDICA EASY MRP30', 'INDICA EASY MRP30', '1310', NULL, 29.00, 29.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:17:44', '2024-05-14 09:17:44', NULL),
(490, 'BLOCK ROSE MRP12', 'BLOCK ROSE MRP12', '1311', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:18:32', '2024-05-14 09:18:32', NULL),
(491, 'JOHNSONS BABY SOAP [MRP83]', 'JOHNSONS BABY SOAP [MRP83]', '1312', NULL, 80.00, 80.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:19:59', '2024-05-14 09:19:59', NULL),
(492, 'JEERAGATHUL 50GMS', 'சீரகத்துள்50GMS', '1315', NULL, 34.00, 34.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:48:33', '2024-05-14 09:48:33', NULL),
(493, 'UJALA NEELAM MRP32', 'Ujala நீலம் [MRP32]', '1316', NULL, 30.00, 30.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 09:50:42', '2024-05-14 09:50:42', NULL),
(494, 'BUDS MRP30', 'BUDS MRP30', '1317', NULL, 25.00, 25.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:09:59', '2024-05-14 10:09:59', NULL),
(495, 'Surf XL Powder 500GMS[MRP110]', 'Surf XL Powder 500GMS[MRP110]', '1318', NULL, 105.00, 105.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:14:02', '2024-05-14 10:14:02', NULL),
(496, 'Surf XL Powder MRP10', 'Surf XL Powder MRP10', '1319', NULL, 9.80, 9.80, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:14:41', '2024-05-14 10:14:41', NULL),
(497, 'DOVE SOAP MRP42', 'DOVE SOAP MRP42', '1320', NULL, 40.00, 40.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:20:36', '2024-05-14 10:20:36', NULL),
(498, 'Nalan Dates MRP75', 'Nalan Dates MRP75', '1321', NULL, 70.00, 70.00, 'standard', 'exclusive', 7, 7, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:23:32', '2024-05-14 10:23:32', NULL),
(499, 'DATES 200GMS', 'DATES 200GMS', '1313', NULL, 25.00, 25.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:24:26', '2024-05-14 10:24:26', NULL),
(500, 'THIERI RS1', ' திரி RS1', '1322', NULL, 1.00, 1.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:25:59', '2024-05-14 10:25:59', NULL),
(501, 'THIRI RS2', ' திரி RS2', '1323', NULL, 2.00, 2.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:26:33', '2024-05-14 10:26:33', NULL),
(502, 'GOKUL POWDER MRP75', 'GOKUL POWDER MRP75', '1324', NULL, 73.00, 73.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:28:49', '2024-05-14 10:28:49', NULL),
(503, 'GOKUL POWDER MRP43', 'GOKUL POWDER MRP43', '1326', NULL, 42.00, 42.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:29:15', '2024-05-14 10:29:15', NULL),
(504, 'GOKUL POWDER MRP129', 'GOKUL POWDER MRP129', '1327', NULL, 125.00, 125.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:29:55', '2024-05-14 10:29:55', NULL),
(505, 'Dettol Liquid 200MIL[MRP140]', 'Dettol Liquid 200MIL[MRP140]', '1328', NULL, 135.00, 135.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:34:17', '2024-05-14 10:34:17', NULL),
(506, 'Dettol Liquid 100MIL[MRP73]', 'Dettol Liquid 100MIL[MRP73]', '1329', NULL, 70.00, 70.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:34:53', '2024-05-14 10:34:53', NULL),
(507, 'Dettol Liquid 50MIL[MRP40]', 'Dettol Liquid 50MIL[MRP40]', '1330', NULL, 38.00, 38.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:35:26', '2024-05-14 10:35:26', NULL),
(508, 'LION SYRUP 500MIL[MRP200]', 'LION SYRUP 500MIL[MRP200]', '1331', NULL, 190.00, 190.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:36:09', '2024-05-14 10:36:09', NULL),
(509, 'LION SYRUP 250MIL[MRP107]', 'LION SYRUP 250MIL[MRP107]', '1332', NULL, 100.00, 100.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:36:41', '2024-05-14 10:36:41', NULL),
(510, 'RISE SAMPOO [MRP190]500MILL', 'RISE SAMPOO [MRP190]500MIL', '1333', NULL, 180.00, 180.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:40:36', '2024-05-14 10:40:36', NULL),
(511, 'Comfort 250MIL [MRP58]', 'Comfort 250MIL [MRP58]', '1334', NULL, 56.00, 56.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:42:34', '2024-05-14 10:42:34', NULL),
(512, 'Comfort RS4', 'Comfort RS4', '1335', NULL, 38.00, 38.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:43:09', '2024-05-14 10:43:09', NULL),
(513, 'Comfort BLK RS65', 'Comfort BLK RS65', '1336', NULL, 63.00, 63.00, 'standard', 'exclusive', 4, 4, 4, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:43:42', '2024-05-14 10:43:42', NULL),
(514, 'DOVE SAMPOO RS2', 'DOVE SAMPOO RS2', '1337', NULL, 28.00, 28.00, 'standard', 'exclusive', 9, 9, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:47:59', '2024-05-14 10:47:59', NULL),
(515, 'CINTHOL SOAP RS10', 'CINTHOL SOAP RS10', '1338', NULL, 9.80, 9.80, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 10:51:17', '2024-05-14 10:51:17', NULL),
(516, 'AIR FRESH MRP60', 'AIR FRESH MRP60', '1339', NULL, 55.00, 55.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 11:04:49', '2024-05-14 11:04:49', NULL),
(517, 'INJIPUNDU PASTE RS5', 'இஞ்சிபூண்டு பேஸ்ட் RS5', '1340', NULL, 5.00, 5.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 11:14:30', '2024-05-14 11:14:30', NULL),
(518, 'MIDMIX (3+1)MRP130', 'MIDMIX (3+1)MRP130', '1341', NULL, 125.00, 125.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:24:03', '2024-05-14 12:24:03', NULL),
(519, 'MIDMIX(3+1)MRP96', 'MIDMIX(3+1)MRP96', '1342', NULL, 92.00, 92.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:25:44', '2024-05-14 12:25:44', NULL),
(520, 'MURUKKU 250GMS', ' முருக்கு 250GMS', '1344', NULL, 45.00, 45.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:32:47', '2024-05-14 12:32:47', NULL),
(521, 'MIXER 250GMS', 'மிக்சர் 250GMS', '1345', NULL, 45.00, 45.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:33:45', '2024-05-14 12:33:45', NULL),
(522, 'WONDER CAKE RS40', 'WONDER CAKE RS40', '1346', NULL, 40.00, 40.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:35:20', '2024-05-14 12:35:20', NULL),
(523, 'FEVIKWIK RS5', 'FEVIKWIK RS5', '1347', NULL, 5.00, 5.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:35:50', '2024-05-14 12:35:50', NULL),
(524, 'MADHU BRIYANI PASTE MRP48', 'மது பிரியாணி பேஸ்ட் MRP48', '1348', NULL, 45.00, 45.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:36:50', '2024-05-14 12:36:50', NULL),
(525, 'WISHPER MRP50', 'விஸ்பர் MRP50', '1349', NULL, 48.00, 48.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:39:32', '2024-05-14 12:39:32', NULL),
(526, 'WISPHER MRP35', 'விஸ்பர் MRP35', '1350', NULL, 33.00, 33.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:40:04', '2024-05-14 12:40:04', NULL),
(527, 'STAYFREEMRP42', 'STAYFREE MRP42', '1351', NULL, 40.00, 40.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:40:52', '2024-05-14 12:40:52', NULL),
(528, 'Z POWDER MRP78', 'Z POWDER MRP78', '1352', NULL, 75.00, 75.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:42:37', '2024-05-14 12:42:37', NULL),
(529, 'SARPATH', ' சர்பத்(ஜனதா)', '1353', NULL, 75.00, 75.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 12:46:36', '2024-05-14 12:46:36', NULL),
(530, 'PANNER  MRP30', 'பன்னீர் MRP30', '1354', NULL, 20.00, 230.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 13:08:28', '2024-05-14 13:08:28', NULL),
(531, 'GOBAL PAL PODI RS10', ' கோபால் பல்பொடி', '1356', NULL, 10.00, 10.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 13:11:12', '2024-05-14 13:11:12', NULL),
(532, 'ARASAN SOAP MRP26', ' அரசன் சோப்[ MRP26]', '1360', NULL, 24.00, 24.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 14:13:41', '2024-05-14 14:13:41', NULL),
(533, 'ARASAN MRP16', ' அரசன் சோப் MRP16', '1361', NULL, 14.00, 14.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 14:14:47', '2024-05-14 14:14:47', NULL),
(534, 'BRU 50GMS POUCH MRP125', 'BRU 50GMS POUCH MRP125', '1362', NULL, 120.00, 120.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 14:43:07', '2024-05-14 14:43:07', NULL),
(535, 'BRU MRP220', 'BRU MRP220', '1367', NULL, 215.00, 215.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 14:45:23', '2024-05-14 14:45:23', NULL),
(536, 'SUNRISE 50GMS POUCH MRP120', 'SUNRISE 50GMS POUCH MRP120', '1363', NULL, 118.00, 118.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 14:45:58', '2024-05-14 14:45:58', NULL),
(537, 'PAPER ', 'பேப்பர் (ENGLISH)', '1364', NULL, 48.00, 48.00, 'standard', 'exclusive', 1, 1, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 14:51:24', '2024-05-14 14:51:24', NULL),
(538, 'FAIR&LOVELY[ MRP62]25GMS', 'FAIR&LOVELY[ MRP62]25GMS', '1370', NULL, 60.00, 60.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 15:09:08', '2024-05-14 15:09:08', NULL),
(539, 'FAIR&LOVELY[ MRP125]50GMS', 'FAIR&LOVELY[ MRP125]50GMS', '1369', NULL, 120.00, 120.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 15:09:50', '2024-05-14 15:09:50', NULL),
(540, 'FAIR&LOVELY[ MRP22]15GMS', 'FAIR&LOVELY[ MRP22]15GMS', '1368', NULL, 20.00, 20.00, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 15:10:31', '2024-05-14 15:10:31', NULL),
(541, 'Ariel பவுடர் Rs.10 ', 'ஏரியல் பவுடர் RS10', '1372', NULL, 9.80, 9.80, 'standard', 'exclusive', 4, 4, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 15:13:38', '2024-05-14 15:13:38', NULL),
(542, 'RIN POWDER MRP60', ' ரின் பவுடர் [MRP60]', '1371', NULL, 58.00, 58.00, 'standard', 'exclusive', 3, 3, NULL, 0.00, NULL, NULL, NULL, NULL, 1, 0, NULL, '2024-05-14 15:16:07', '2024-05-14 15:16:07', NULL);

CREATE TABLE `product_variants` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` int(11) DEFAULT NULL,
  `sku` varchar(191) NOT NULL,
  `name` varchar(192) DEFAULT NULL,
  `cost` double DEFAULT 0,
  `price` double DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `purchases` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` int(11) NOT NULL,
  `date` datetime NOT NULL,
  `supplier_id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` int(11) DEFAULT 0,
  `tax_rate` double DEFAULT 0,
  `tax_net` double DEFAULT 0,
  `discount` double DEFAULT 0,
  `shipping_amount` double DEFAULT 0,
  `discount_type` varchar(192) NOT NULL,
  `grand_total` double NOT NULL DEFAULT 0,
  `paid_amount` double NOT NULL DEFAULT 0,
  `payment_status` varchar(192) NOT NULL,
  `status` varchar(191) NOT NULL,
  `notes` text DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `purchases_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `purchase_returns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `supplier_id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` int(11) DEFAULT 0,
  `date` datetime NOT NULL,
  `return_invoice_number` varchar(255) NOT NULL,
  `tax_rate` double DEFAULT 0,
  `tax_amount` double DEFAULT 0,
  `discount` double DEFAULT 0,
  `discount_type` varchar(192) NOT NULL,
  `grand_total` double NOT NULL DEFAULT 0,
  `paid_amount` double NOT NULL DEFAULT 0,
  `payment_status` varchar(192) NOT NULL,
  `status` varchar(191) NOT NULL,
  `notes` text DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `purchase_return_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_return_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `purchase_return_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `purchase_return_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `payment_method_id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `change` double NOT NULL DEFAULT 0,
  `payment_notes` varchar(192) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `roles` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `description` varchar(255) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `roles` (`id`, `name`, `description`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 'admin', NULL, NULL, '2024-03-10 22:01:34', '2024-03-10 22:01:34');

CREATE TABLE `role_permission` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED NOT NULL,
  `permission_id` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `role_permission` (`id`, `role_id`, `permission_id`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL),
(2, 1, 2, NULL, NULL),
(3, 1, 3, NULL, NULL),
(4, 1, 4, NULL, NULL),
(5, 1, 5, NULL, NULL),
(6, 1, 6, NULL, NULL),
(7, 1, 7, NULL, NULL),
(8, 1, 8, NULL, NULL),
(9, 1, 9, NULL, NULL),
(10, 1, 10, NULL, NULL),
(11, 1, 11, NULL, NULL),
(12, 1, 12, NULL, NULL),
(13, 1, 13, NULL, NULL),
(14, 1, 14, NULL, NULL),
(15, 1, 15, NULL, NULL),
(16, 1, 16, NULL, NULL),
(17, 1, 17, NULL, NULL),
(18, 1, 18, NULL, NULL),
(19, 1, 19, NULL, NULL),
(20, 1, 20, NULL, NULL),
(21, 1, 21, NULL, NULL),
(22, 1, 22, NULL, NULL),
(23, 1, 23, NULL, NULL),
(24, 1, 24, NULL, NULL),
(25, 1, 25, NULL, NULL),
(26, 1, 26, NULL, NULL),
(27, 1, 27, NULL, NULL),
(28, 1, 28, NULL, NULL),
(29, 1, 29, NULL, NULL),
(30, 1, 30, NULL, NULL),
(31, 1, 31, NULL, NULL),
(32, 1, 32, NULL, NULL),
(33, 1, 33, NULL, NULL),
(34, 1, 34, NULL, NULL),
(35, 1, 35, NULL, NULL),
(36, 1, 36, NULL, NULL),
(37, 1, 37, NULL, NULL),
(38, 1, 38, NULL, NULL),
(39, 1, 39, NULL, NULL),
(40, 1, 40, NULL, NULL),
(41, 1, 41, NULL, NULL),
(42, 1, 42, NULL, NULL),
(43, 1, 43, NULL, NULL),
(44, 1, 44, NULL, NULL),
(45, 1, 45, NULL, NULL),
(46, 1, 46, NULL, NULL),
(47, 1, 47, NULL, NULL),
(48, 1, 48, NULL, NULL),
(49, 1, 49, NULL, NULL),
(50, 1, 50, NULL, NULL),
(51, 1, 51, NULL, NULL),
(52, 1, 52, NULL, NULL),
(53, 1, 53, NULL, NULL),
(54, 1, 54, NULL, NULL),
(55, 1, 55, NULL, NULL),
(56, 1, 56, NULL, NULL),
(57, 1, 57, NULL, NULL);

CREATE TABLE `sales` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `date` datetime NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `invoice_number` varchar(255) NOT NULL,
  `warehouse_id` int(11) DEFAULT 0,
  `tax_rate` double DEFAULT 0,
  `tax_amount` double DEFAULT 0,
  `discount` double DEFAULT 0,
  `discount_type` varchar(192) NOT NULL,
  `grand_total` double NOT NULL DEFAULT 0,
  `paid_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double DEFAULT 0,
  `payment_status` varchar(192) NOT NULL,
  `status` varchar(191) NOT NULL,
  `notes` text DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sales` (`id`, `user_id`, `date`, `customer_id`, `invoice_number`, `warehouse_id`, `tax_rate`, `tax_amount`, `discount`, `discount_type`, `grand_total`, `paid_amount`, `shipping_amount`, `payment_status`, `status`, `notes`, `deleted_by`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, '2024-05-13 10:26:00', 1, '1001', 1, 0, 0, 0, 'fixed', 1667.5, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 04:56:35', '2024-05-13 04:56:35'),
(2, 1, '2024-05-13 10:27:00', 1, '1002', 1, 0, 0, 0, 'fixed', 175, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 04:58:09', '2024-05-13 04:58:09'),
(3, 1, '2024-05-13 10:34:00', 1, '1003', 1, 0, 0, 0, 'fixed', 2288, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 05:05:10', '2024-05-13 05:05:10'),
(4, 1, '2024-05-13 10:35:00', 1, '1004', 1, 0, 0, 0, 'fixed', 240, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 05:11:06', '2024-05-13 05:11:06'),
(5, 1, '2024-05-13 12:47:00', 2, '1005', 1, 0, 0, 0, 'fixed', 4505, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(6, 1, '2024-05-13 17:36:00', 1, '1006', 1, 0, 0, 0, 'fixed', 68, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 12:06:30', '2024-05-13 12:06:30'),
(7, 1, '2024-05-13 18:07:00', 1, '1007', 1, 0, 0, 0, 'fixed', 14, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 12:38:01', '2024-05-13 12:38:01'),
(8, 1, '2024-05-13 20:41:00', 1, '1008', 1, 0, 0, 0, 'fixed', 750, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-13 15:12:38', '2024-05-13 15:12:38'),
(9, 1, '2024-05-14 11:38:00', 1, '1009', 1, 0, 0, 0, 'fixed', 74, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 06:09:18', '2024-05-14 06:09:18'),
(10, 1, '2024-05-14 11:42:00', 1, '1010', 1, 0, 0, 0, 'fixed', 2035.5, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(11, 1, '2024-05-14 14:32:00', 1, '1011', 1, 0, 0, 0, 'fixed', 120, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 09:03:13', '2024-05-14 09:03:13'),
(12, 1, '2024-05-14 14:43:00', 1, '1012', 1, 0, 0, 0, 'fixed', 30, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 09:13:21', '2024-05-14 09:13:21'),
(13, 1, '2024-05-14 15:37:00', 1, '1013', 1, 0, 0, 0, 'fixed', 30, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 10:07:45', '2024-05-14 10:07:45'),
(14, 1, '2024-05-14 16:21:00', 1, '1014', 1, 0, 0, 0, 'fixed', 9.8, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 10:52:19', '2024-05-14 10:52:19'),
(15, 1, '2024-05-14 16:24:00', 1, '1015', 1, 0, 0, 0, 'fixed', 35, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 10:55:10', '2024-05-14 10:55:10'),
(16, 1, '2024-05-14 16:25:00', 1, '1016', 1, 0, 0, 0, 'fixed', 1372, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 11:02:56', '2024-05-14 11:02:56'),
(17, 1, '2024-05-14 16:32:00', 1, '1017', 1, 0, 0, 0, 'fixed', 10, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 11:05:08', '2024-05-14 11:05:08'),
(18, 1, '2024-05-14 16:44:00', 1, '1018', 1, 0, 0, 0, 'fixed', 5, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 11:15:05', '2024-05-14 11:15:05'),
(19, 1, '2024-05-14 19:00:00', 1, '1019', 1, 0, 0, 0, 'fixed', 124, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 13:33:28', '2024-05-14 13:33:28'),
(20, 1, '2024-05-14 19:23:00', 1, '1020', 1, 0, 0, 0, 'fixed', 2497, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(21, 1, '2024-05-14 20:00:00', 1, '1021', 1, 0, 0, 0, 'fixed', 187, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-14 14:31:09', '2024-05-14 14:31:09'),
(22, 1, '2024-05-15 12:31:00', 1, '1022', 1, 0, 0, 0, 'fixed', 725, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:01:23', '2024-05-15 07:01:23'),
(23, 1, '2024-05-15 12:43:00', 2, '1023', 1, 0, 0, 0, 'fixed', 5685, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(24, 1, '2024-05-15 13:09:00', 1, '1024', 1, 0, 0, 0, 'fixed', 340, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:40:54', '2024-05-15 07:40:54'),
(25, 1, '2024-05-15 13:10:00', 1, '1025', 1, 0, 0, 0, 'fixed', 59.5, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:41:56', '2024-05-15 07:41:56'),
(26, 1, '2024-05-15 13:11:00', 1, '1026', 1, 0, 0, 0, 'fixed', 429.5, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:43:59', '2024-05-15 07:43:59'),
(27, 1, '2024-05-15 13:16:00', 1, '1027', 1, 0, 0, 0, 'fixed', 387.5, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:48:34', '2024-05-15 07:48:34'),
(28, 1, '2024-05-15 13:16:00', 1, '1028', 1, 0, 0, 0, 'fixed', 150, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:49:58', '2024-05-15 07:49:58'),
(29, 1, '2024-05-15 13:19:00', 1, '1029', 1, 0, 0, 0, 'fixed', 87.5, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:50:24', '2024-05-15 07:50:24'),
(30, 1, '2024-05-15 13:20:00', 1, '1030', 1, 0, 0, 0, 'fixed', 125, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:51:56', '2024-05-15 07:51:56'),
(31, 1, '2024-05-15 13:21:00', 1, '1031', 1, 0, 0, 0, 'fixed', 130, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:52:26', '2024-05-15 07:52:26'),
(32, 1, '2024-05-15 13:24:00', 1, '1032', 1, 0, 0, 0, 'fixed', 8125, 0, 0, 'Unpaid', 'new', '', NULL, NULL, '2024-05-15 07:55:16', '2024-05-15 07:55:16');

CREATE TABLE `sales_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sale_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `unit_id` bigint(20) DEFAULT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `sales_items` (`id`, `sale_id`, `product_id`, `unit_id`, `variant_id`, `quantity`, `price`, `subtotal`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 1, NULL, NULL, 1, 17.50, 17.50, NULL, '2024-05-13 04:56:35', '2024-05-13 04:56:35'),
(2, 1, 86, NULL, NULL, 1, 1650.00, 1650.00, NULL, '2024-05-13 04:56:35', '2024-05-13 04:56:35'),
(3, 2, 1, NULL, NULL, 1, 175.00, 175.00, NULL, '2024-05-13 04:58:09', '2024-05-13 04:58:09'),
(4, 3, 101, NULL, NULL, 1, 160.00, 160.00, NULL, '2024-05-13 05:05:10', '2024-05-13 05:05:10'),
(5, 3, 171, NULL, NULL, 1, 730.00, 730.00, NULL, '2024-05-13 05:05:10', '2024-05-13 05:05:10'),
(6, 3, 70, NULL, NULL, 1, 40.00, 40.00, NULL, '2024-05-13 05:05:10', '2024-05-13 05:05:10'),
(7, 3, 208, NULL, NULL, 1, 1358.00, 1358.00, NULL, '2024-05-13 05:05:10', '2024-05-13 05:05:10'),
(8, 4, 24, NULL, NULL, 1, 240.00, 240.00, NULL, '2024-05-13 05:11:06', '2024-05-13 05:11:06'),
(9, 5, 212, NULL, NULL, 1, 400.00, 400.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(10, 5, 166, NULL, NULL, 1, 750.00, 750.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(11, 5, 79, NULL, NULL, 1, 325.00, 325.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(12, 5, 351, NULL, NULL, 1, 50.00, 50.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(13, 5, 175, NULL, NULL, 1, 130.00, 130.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(14, 5, 85, NULL, NULL, 1, 100.00, 100.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(15, 5, 18, NULL, NULL, 1, 60.00, 60.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(16, 5, 21, NULL, NULL, 1, 65.00, 65.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(17, 5, 366, NULL, NULL, 1, 84.00, 84.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(18, 5, 349, NULL, NULL, 1, 80.00, 80.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(19, 5, 251, NULL, NULL, 1, 36.00, 36.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(20, 5, 361, NULL, NULL, 1, 58.00, 58.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(21, 5, 354, NULL, NULL, 1, 30.00, 30.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(22, 5, 77, NULL, NULL, 1, 250.00, 250.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(23, 5, 321, NULL, NULL, 1, 220.00, 220.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(24, 5, 51, NULL, NULL, 1, 90.00, 90.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(25, 5, 84, NULL, NULL, 1, 12.00, 12.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(26, 5, 82, NULL, NULL, 2, 32.50, 65.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(27, 5, 81, NULL, NULL, 1, 12.00, 12.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(28, 5, 2, NULL, NULL, 1, 125.00, 125.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(29, 5, 4, NULL, NULL, 1, 420.00, 420.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(30, 5, 8, NULL, NULL, 2, 270.00, 540.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(31, 5, 36, NULL, NULL, 1, 104.00, 104.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(32, 5, 319, NULL, NULL, 1, 215.00, 215.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(33, 5, 343, NULL, NULL, 1, 215.00, 215.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(34, 5, 24, NULL, NULL, 1, 24.00, 24.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(35, 5, 344, NULL, NULL, 1, 27.00, 27.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(36, 5, 345, NULL, NULL, 1, 18.00, 18.00, NULL, '2024-05-13 07:52:57', '2024-05-13 07:52:57'),
(37, 6, 46, NULL, NULL, 1, 68.00, 68.00, NULL, '2024-05-13 12:06:30', '2024-05-13 12:06:30'),
(38, 7, 154, NULL, NULL, 1, 14.00, 14.00, NULL, '2024-05-13 12:38:01', '2024-05-13 12:38:01'),
(39, 8, 441, NULL, NULL, 1, 750.00, 750.00, NULL, '2024-05-13 15:12:38', '2024-05-13 15:12:38'),
(40, 9, 430, NULL, NULL, 1, 74.00, 74.00, NULL, '2024-05-14 06:09:18', '2024-05-14 06:09:18'),
(41, 10, 318, NULL, NULL, 1, 88.00, 88.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(42, 10, 77, NULL, NULL, 1, 62.50, 62.50, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(43, 10, 86, NULL, NULL, 1, 30.00, 30.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(44, 10, 154, NULL, NULL, 1, 14.00, 14.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(45, 10, 343, NULL, NULL, 1, 215.00, 215.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(46, 10, 87, NULL, NULL, 1, 90.00, 90.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(47, 10, 322, NULL, NULL, 1, 34.00, 34.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(48, 10, 81, NULL, NULL, 1, 30.00, 30.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(49, 10, 24, NULL, NULL, 1, 24.00, 24.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(50, 10, 83, NULL, NULL, 1, 80.00, 80.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(51, 10, 82, NULL, NULL, 1, 65.00, 65.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(52, 10, 2, NULL, NULL, 1, 62.50, 62.50, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(53, 10, 10, NULL, NULL, 1, 65.00, 65.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(54, 10, 111, NULL, NULL, 1, 140.00, 140.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(55, 10, 320, NULL, NULL, 1, 560.00, 560.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(56, 10, 8, NULL, NULL, 1, 337.50, 337.50, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(57, 10, 234, NULL, NULL, 1, 138.00, 138.00, NULL, '2024-05-14 06:17:38', '2024-05-14 06:17:38'),
(58, 11, 209, NULL, NULL, 1, 120.00, 120.00, NULL, '2024-05-14 09:03:13', '2024-05-14 09:03:13'),
(59, 12, 292, NULL, NULL, 1, 30.00, 30.00, NULL, '2024-05-14 09:13:21', '2024-05-14 09:13:21'),
(60, 13, 449, NULL, NULL, 1, 30.00, 30.00, NULL, '2024-05-14 10:07:45', '2024-05-14 10:07:45'),
(61, 14, 306, NULL, NULL, 1, 9.80, 9.80, NULL, '2024-05-14 10:52:19', '2024-05-14 10:52:19'),
(62, 15, 111, NULL, NULL, 1, 35.00, 35.00, NULL, '2024-05-14 10:55:10', '2024-05-14 10:55:10'),
(63, 16, 213, NULL, NULL, 1, 1372.00, 1372.00, NULL, '2024-05-14 11:02:56', '2024-05-14 11:02:56'),
(64, 17, 67, NULL, NULL, 1, 10.00, 10.00, NULL, '2024-05-14 11:05:08', '2024-05-14 11:05:08'),
(65, 18, 517, NULL, NULL, 1, 5.00, 5.00, NULL, '2024-05-14 11:15:05', '2024-05-14 11:15:05'),
(66, 19, 347, NULL, NULL, 2, 25.00, 50.00, NULL, '2024-05-14 13:33:28', '2024-05-14 13:33:28'),
(67, 19, 346, NULL, NULL, 1, 50.00, 50.00, NULL, '2024-05-14 13:33:28', '2024-05-14 13:33:28'),
(68, 19, 24, NULL, NULL, 1, 24.00, 24.00, NULL, '2024-05-14 13:33:28', '2024-05-14 13:33:28'),
(69, 20, 31, NULL, NULL, 1, 42.00, 42.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(70, 20, 322, NULL, NULL, 1, 170.00, 170.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(71, 20, 314, NULL, NULL, 1, 60.00, 60.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(72, 20, 343, NULL, NULL, 1, 215.00, 215.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(73, 20, 328, NULL, NULL, 1, 120.00, 120.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(74, 20, 2, NULL, NULL, 1, 250.00, 250.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(75, 20, 1, NULL, NULL, 1, 875.00, 875.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(76, 20, 321, NULL, NULL, 1, 110.00, 110.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(77, 20, 320, NULL, NULL, 1, 560.00, 560.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(78, 20, 409, NULL, NULL, 1, 20.00, 20.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(79, 20, 347, NULL, NULL, 1, 25.00, 25.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(80, 20, 346, NULL, NULL, 1, 50.00, 50.00, NULL, '2024-05-14 13:55:15', '2024-05-14 13:55:15'),
(81, 21, 363, NULL, NULL, 1, 85.00, 85.00, NULL, '2024-05-14 14:31:09', '2024-05-14 14:31:09'),
(82, 21, 364, NULL, NULL, 1, 53.00, 53.00, NULL, '2024-05-14 14:31:09', '2024-05-14 14:31:09'),
(83, 21, 360, NULL, NULL, 1, 49.00, 49.00, NULL, '2024-05-14 14:31:09', '2024-05-14 14:31:09'),
(84, 22, 368, NULL, NULL, 1, 725.00, 725.00, NULL, '2024-05-15 07:01:23', '2024-05-15 07:01:23'),
(85, 23, 368, NULL, NULL, 1, 725.00, 725.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(86, 23, 212, NULL, NULL, 1, 400.00, 400.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(87, 23, 79, NULL, NULL, 1, 585.00, 585.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(88, 23, 351, NULL, NULL, 1, 50.00, 50.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(89, 23, 175, NULL, NULL, 1, 130.00, 130.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(90, 23, 85, NULL, NULL, 1, 100.00, 100.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(91, 23, 18, NULL, NULL, 1, 120.00, 120.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(92, 23, 21, NULL, NULL, 1, 65.00, 65.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(93, 23, 366, NULL, NULL, 1, 84.00, 84.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(94, 23, 349, NULL, NULL, 1, 80.00, 80.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(95, 23, 251, NULL, NULL, 1, 36.00, 36.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(96, 23, 361, NULL, NULL, 1, 58.00, 58.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(97, 23, 354, NULL, NULL, 1, 30.00, 30.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(98, 23, 77, NULL, NULL, 1, 250.00, 250.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(99, 23, 321, NULL, NULL, 1, 220.00, 220.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(100, 23, 51, NULL, NULL, 1, 90.00, 90.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(101, 23, 84, NULL, NULL, 1, 12.00, 12.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(102, 23, 82, NULL, NULL, 1, 195.00, 195.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(103, 23, 81, NULL, NULL, 1, 12.00, 12.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(104, 23, 2, NULL, NULL, 1, 125.00, 125.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(105, 23, 4, NULL, NULL, 1, 420.00, 420.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(106, 23, 1, NULL, NULL, 1, 350.00, 350.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(107, 23, 8, NULL, NULL, 1, 945.00, 945.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(108, 23, 36, NULL, NULL, 1, 104.00, 104.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(109, 23, 319, NULL, NULL, 1, 215.00, 215.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(110, 23, 343, NULL, NULL, 1, 215.00, 215.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(111, 23, 24, NULL, NULL, 1, 24.00, 24.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(112, 23, 344, NULL, NULL, 1, 27.00, 27.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(113, 23, 345, NULL, NULL, 1, 18.00, 18.00, NULL, '2024-05-15 07:22:10', '2024-05-15 07:22:10'),
(114, 24, 442, 1, NULL, 1, 68.00, 68.00, NULL, '2024-05-15 07:40:54', '2024-05-15 07:40:54'),
(115, 25, 10, 1, NULL, 1, 130.00, 130.00, NULL, '2024-05-15 07:41:56', '2024-05-15 07:41:56'),
(116, 25, 344, 1, NULL, 1, 27.00, 27.00, NULL, '2024-05-15 07:41:56', '2024-05-15 07:41:56'),
(117, 26, 208, 1, NULL, 1, 97.00, 97.00, NULL, '2024-05-15 07:43:59', '2024-05-15 07:43:59'),
(118, 26, 73, 2, NULL, 1, 65.00, 65.00, NULL, '2024-05-15 07:43:59', '2024-05-15 07:43:59'),
(119, 26, 71, 3, NULL, 1, 300.00, 300.00, NULL, '2024-05-15 07:43:59', '2024-05-15 07:43:59'),
(120, 27, 1, 2, NULL, 1, 175.00, 175.00, NULL, '2024-05-15 07:48:34', '2024-05-15 07:48:34'),
(121, 27, 369, 3, NULL, 1, 30.00, 30.00, NULL, '2024-05-15 07:48:34', '2024-05-15 07:48:34'),
(122, 28, 166, 2, NULL, 1, 3000.00, 3000.00, NULL, '2024-05-15 07:49:58', '2024-05-15 07:49:58'),
(123, 29, 1, 2, NULL, 1, 175.00, 175.00, NULL, '2024-05-15 07:50:24', '2024-05-15 07:50:24'),
(124, 30, 2, 1, NULL, 1, 125.00, 125.00, NULL, '2024-05-15 07:51:56', '2024-05-15 07:51:56'),
(125, 31, 10, 1, NULL, 1, 130.00, 130.00, NULL, '2024-05-15 07:52:26', '2024-05-15 07:52:26'),
(126, 32, 83, 2, NULL, 100, 800.00, 80000.00, NULL, '2024-05-15 07:55:16', '2024-05-15 07:55:16'),
(127, 32, 2, 1, NULL, 1, 125.00, 125.00, NULL, '2024-05-15 07:55:16', '2024-05-15 07:55:16');

CREATE TABLE `sales_returns` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sale_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `customer_id` bigint(20) UNSIGNED NOT NULL,
  `warehouse_id` int(11) DEFAULT 0,
  `date` datetime NOT NULL,
  `return_invoice_number` varchar(255) NOT NULL,
  `tax_rate` double DEFAULT 0,
  `tax_amount` double DEFAULT 0,
  `discount` double DEFAULT 0,
  `discount_type` varchar(192) NOT NULL,
  `grand_total` double NOT NULL DEFAULT 0,
  `paid_amount` double NOT NULL DEFAULT 0,
  `payment_status` varchar(192) NOT NULL,
  `status` varchar(191) NOT NULL,
  `notes` text DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `sales_return_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sales_return_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `sales_return_payments` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `sales_return_id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `amount` double NOT NULL,
  `payment_method_id` bigint(20) UNSIGNED NOT NULL,
  `account_id` int(11) DEFAULT NULL,
  `date` datetime DEFAULT NULL,
  `change` double NOT NULL DEFAULT 0,
  `payment_notes` varchar(192) DEFAULT NULL,
  `notes` text DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `settings` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `settings` (`id`, `key`, `value`, `created_at`, `updated_at`) VALUES
(1, 'company_name', 'பாண்டியன் மளிகை', NULL, '2024-05-13 08:20:20'),
(2, 'company_email', 'contact@yourcompany.com', NULL, NULL),
(3, 'company_phone', '/GPAY9751884884', NULL, '2024-05-13 08:20:38'),
(4, 'company_vat', 'PL6541215450', NULL, NULL),
(5, 'company_address', 'ஒட்டன்சத்திரம்', NULL, '2024-05-13 08:20:20'),
(6, 'company_pincode', '123456', NULL, NULL),
(7, 'company_gst_no', '22AAAAA0000A1Z5', NULL, NULL),
(8, 'company_state', 'Your State', NULL, NULL),
(9, 'company_country', 'India', NULL, NULL),
(10, 'app_name', 'Elite POS', NULL, NULL),
(11, 'developed_by', 'Dream Coderz', NULL, NULL),
(12, 'app_footer', ' ', NULL, '2024-05-13 04:59:18'),
(13, 'default_customer', '1', NULL, NULL),
(14, 'default_warehouse', '1', NULL, NULL),
(15, 'default_currency', 'INR', NULL, NULL),
(16, 'currency_symbol', '₹', NULL, NULL),
(17, 'categories_enabled', 'true', NULL, '2024-03-11 04:17:33'),
(18, 'warehouses_enabled', 'false', NULL, '2024-03-11 04:17:28'),
(19, 'brands_enabled', 'true', NULL, NULL),
(20, 'stocks_enabled', 'flase', NULL, NULL),
(21, 'units_enabled', 'true', NULL, NULL),
(22, 'purchases_enabled', 'true', NULL, NULL),
(23, 'pos_enabled', 'true', NULL, NULL),
(24, 'accounting_enabled', 'true', NULL, NULL),
(25, 'invoice_prefix', '', NULL, NULL),
(26, 'invoice_suffix', '', NULL, NULL),
(27, 'last_invoice_number', '1032', NULL, NULL),
(28, 'time_zone', 'Asia/Kolkata', NULL, NULL);

CREATE TABLE `stocks` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `warehouse_id` bigint(20) UNSIGNED DEFAULT 1,
  `batch_number` varchar(255) DEFAULT NULL,
  `expiry_date` date DEFAULT NULL,
  `date` datetime NOT NULL,
  `quantity` int(11) NOT NULL,
  `type` enum('Addition','Subtraction') NOT NULL,
  `movement_reason` enum('Sale','Purchase','Sales Return','Purchase Return','Stock Adjustment_Addition','Stock Adjustment_Subtraction','Transfer Out','Transfer In','Write-Off','Reconciliation') NOT NULL,
  `related_order_id` bigint(20) UNSIGNED DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `suppliers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `phone` varchar(191) DEFAULT NULL,
  `email` varchar(192) DEFAULT NULL,
  `address` text DEFAULT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `transactions` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `warehouse_id` bigint(20) UNSIGNED DEFAULT NULL,
  `type` enum('sale','purchase','sales_return','purchase_return') NOT NULL,
  `quantity` int(11) NOT NULL,
  `transaction_date` datetime NOT NULL,
  `created_by` bigint(20) UNSIGNED NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `transfers` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `user_id` bigint(20) UNSIGNED NOT NULL,
  `date` datetime NOT NULL,
  `from_warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `to_warehouse_id` bigint(20) UNSIGNED NOT NULL,
  `tax_rate` double DEFAULT 0,
  `tax_amount` double DEFAULT 0,
  `discount` double DEFAULT 0,
  `discount_type` varchar(192) NOT NULL,
  `grand_total` double NOT NULL DEFAULT 0,
  `paid_amount` double NOT NULL DEFAULT 0,
  `shipping_amount` double DEFAULT 0,
  `payment_status` varchar(192) NOT NULL,
  `status` varchar(191) NOT NULL,
  `notes` text DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `transfers_items` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `transfer_id` bigint(20) UNSIGNED NOT NULL,
  `product_id` bigint(20) UNSIGNED NOT NULL,
  `variant_id` bigint(20) UNSIGNED DEFAULT NULL,
  `quantity` int(11) NOT NULL,
  `price` decimal(8,2) NOT NULL,
  `subtotal` decimal(8,2) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE TABLE `units` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(192) NOT NULL,
  `short_name` varchar(192) NOT NULL,
  `base_unit` int(11) DEFAULT NULL,
  `operator` char(192) DEFAULT '*',
  `operator_value` double DEFAULT 1,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `units` (`id`, `name`, `short_name`, `base_unit`, `operator`, `operator_value`, `created_by`, `deleted_by`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Kilogram', 'kg', NULL, '*', 1, NULL, NULL, '2024-01-10 01:58:05', '2024-01-10 01:58:05', NULL),
(2, 'Grams', 'gms', 1, '/', 1000, NULL, NULL, '2024-01-10 01:58:56', '2024-05-15 07:36:46', NULL),
(3, 'Pocket', 'pkt', NULL, '*', 1, NULL, NULL, '2024-01-10 01:59:15', '2024-01-10 02:00:14', NULL),
(4, 'Pieces', 'pcs', NULL, '*', 1, NULL, NULL, '2024-01-10 02:00:43', '2024-01-10 02:00:43', NULL),
(5, 'Litre ', 'ltr ', NULL, '*', 1, NULL, NULL, '2024-01-10 08:47:25', '2024-01-10 08:47:25', NULL),
(6, 'Milli Litre ', 'ml ', 5, '*', 1000, NULL, NULL, '2024-01-10 08:48:46', '2024-01-10 08:48:46', NULL),
(7, 'Box ', 'box ', NULL, '*', 1, NULL, NULL, '2024-01-12 01:07:43', '2024-01-12 01:07:43', NULL),
(8, 'Bag ', 'bag ', NULL, '*', 1, NULL, NULL, '2024-01-15 12:09:11', '2024-01-15 12:09:11', NULL),
(9, 'சரம்', 'சரம்', NULL, '*', 1, NULL, NULL, '2024-05-13 09:44:09', '2024-05-13 09:44:09', NULL);

CREATE TABLE `users` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `role_id` bigint(20) UNSIGNED DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `created_by` bigint(20) UNSIGNED DEFAULT NULL,
  `deleted_by` bigint(20) UNSIGNED DEFAULT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `users` (`id`, `role_id`, `name`, `username`, `password`, `created_by`, `deleted_by`, `remember_token`, `deleted_at`, `created_at`, `updated_at`) VALUES
(1, 1, 'admin', 'admin', '$2y$12$zgdnqQEUY8W2vFsDrrX4sePbeQCO3BkSjalzwGhJ6nUOc1gOSjoou', NULL, NULL, NULL, NULL, '2024-03-10 22:01:46', '2024-03-10 22:01:46');

CREATE TABLE `warehouses` (
  `id` bigint(20) UNSIGNED NOT NULL,
  `name` varchar(255) NOT NULL,
  `address` varchar(255) DEFAULT NULL,
  `pincode` varchar(255) DEFAULT NULL,
  `phone` varchar(255) DEFAULT NULL,
  `city` varchar(255) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

INSERT INTO `warehouses` (`id`, `name`, `address`, `pincode`, `phone`, `city`, `created_at`, `updated_at`, `deleted_at`) VALUES
(1, 'Main', NULL, NULL, NULL, NULL, '2024-03-10 22:01:33', '2024-03-10 22:01:33', NULL);


ALTER TABLE `accounts`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `audit_logs`
  ADD PRIMARY KEY (`id`),
  ADD KEY `audit_logs_user_id_foreign` (`user_id`);

ALTER TABLE `brands`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `categories`
  ADD PRIMARY KEY (`id`),
  ADD KEY `categories_parent_id_foreign` (`parent_id`);

ALTER TABLE `currencies`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `customers`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `deposits`
  ADD PRIMARY KEY (`id`),
  ADD KEY `deposit_account_id` (`account_id`),
  ADD KEY `deposit_category_id` (`deposit_category_id`),
  ADD KEY `deposit_payment_method_id` (`payment_method_id`);

ALTER TABLE `deposit_categories`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `expenses`
  ADD PRIMARY KEY (`id`),
  ADD KEY `expenses_account_id` (`account_id`),
  ADD KEY `expenses_category_id` (`expense_category_id`),
  ADD KEY `expenses_payment_method_id` (`payment_method_id`);

ALTER TABLE `expense_categories`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `failed_jobs`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`);

ALTER TABLE `media`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `media_uuid_unique` (`uuid`),
  ADD KEY `media_model_type_model_id_index` (`model_type`,`model_id`),
  ADD KEY `media_order_column_index` (`order_column`);

ALTER TABLE `migrations`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `password_resets`
  ADD KEY `password_resets_email_index` (`email`);

ALTER TABLE `password_reset_tokens`
  ADD PRIMARY KEY (`username`);

ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `payment_purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_purchases_purchase_id_index` (`purchase_id`),
  ADD KEY `payment_purchases_user_id_index` (`user_id`),
  ADD KEY `account_id_payment_purchases` (`account_id`);

ALTER TABLE `payment_sales`
  ADD PRIMARY KEY (`id`),
  ADD KEY `payment_sales_sale_id_index` (`sale_id`),
  ADD KEY `payment_sales_user_id_index` (`user_id`),
  ADD KEY `account_id_payment_sales` (`account_id`);

ALTER TABLE `permissions`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `permission_groups`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `personal_access_tokens`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `personal_access_tokens_token_unique` (`token`),
  ADD KEY `personal_access_tokens_tokenable_type_tokenable_id_index` (`tokenable_type`,`tokenable_id`);

ALTER TABLE `products`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `products_sku_unique` (`sku`);

ALTER TABLE `product_variants`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `purchases`
  ADD PRIMARY KEY (`id`),
  ADD KEY `user_id_purchase` (`user_id`),
  ADD KEY `sale_supplier` (`supplier_id`);

ALTER TABLE `purchases_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchases_items_purchase_id_foreign` (`purchase_id`),
  ADD KEY `purchases_items_product_id_foreign` (`product_id`);

ALTER TABLE `purchase_returns`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `purchase_returns_return_invoice_number_unique` (`return_invoice_number`),
  ADD KEY `purchase_returns_purchase_id_foreign` (`purchase_id`),
  ADD KEY `purchase_returns_user_id_index` (`user_id`),
  ADD KEY `purchases_return_supplier` (`supplier_id`);

ALTER TABLE `purchase_return_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_return_items_purchase_return_id_foreign` (`purchase_return_id`),
  ADD KEY `purchase_return_items_product_id_foreign` (`product_id`);

ALTER TABLE `purchase_return_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `purchase_return_payments_purchase_return_id_index` (`purchase_return_id`),
  ADD KEY `purchase_return_payments_user_id_index` (`user_id`),
  ADD KEY `account_id_payment_purchases` (`account_id`);

ALTER TABLE `roles`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `role_permission`
  ADD PRIMARY KEY (`id`),
  ADD KEY `role_permission_role_id_foreign` (`role_id`),
  ADD KEY `role_permission_permission_id_foreign` (`permission_id`);

ALTER TABLE `sales`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sales_invoice_number_unique` (`invoice_number`),
  ADD KEY `user_id_sales` (`user_id`),
  ADD KEY `sale_customer` (`customer_id`);

ALTER TABLE `sales_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_items_sale_id_foreign` (`sale_id`),
  ADD KEY `sales_items_product_id_foreign` (`product_id`);

ALTER TABLE `sales_returns`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `sales_returns_return_invoice_number_unique` (`return_invoice_number`),
  ADD KEY `sales_returns_sale_id_foreign` (`sale_id`),
  ADD KEY `sales_returns_user_id_index` (`user_id`),
  ADD KEY `sales_retrn_customer` (`customer_id`);

ALTER TABLE `sales_return_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_return_items_sales_return_id_foreign` (`sales_return_id`),
  ADD KEY `sales_return_items_product_id_foreign` (`product_id`);

ALTER TABLE `sales_return_payments`
  ADD PRIMARY KEY (`id`),
  ADD KEY `sales_return_payments_sales_return_id_index` (`sales_return_id`),
  ADD KEY `sales_return_payments_user_id_index` (`user_id`),
  ADD KEY `account_id_payment_sales` (`account_id`);

ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `settings_key_unique` (`key`);

ALTER TABLE `stocks`
  ADD PRIMARY KEY (`id`);

ALTER TABLE `suppliers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `suppliers_created_by_foreign` (`created_by`);

ALTER TABLE `transactions`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transactions_product_id_foreign` (`product_id`),
  ADD KEY `transactions_warehouse_id_foreign` (`warehouse_id`),
  ADD KEY `transactions_created_by_foreign` (`created_by`);

ALTER TABLE `transfers`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transfers_from_warehouse_id_foreign` (`from_warehouse_id`),
  ADD KEY `transfers_to_warehouse_id_foreign` (`to_warehouse_id`),
  ADD KEY `user_id_transfers` (`user_id`);

ALTER TABLE `transfers_items`
  ADD PRIMARY KEY (`id`),
  ADD KEY `transfers_items_transfer_id_foreign` (`transfer_id`),
  ADD KEY `transfers_items_product_id_foreign` (`product_id`);

ALTER TABLE `units`
  ADD PRIMARY KEY (`id`),
  ADD KEY `units_created_by_foreign` (`created_by`),
  ADD KEY `base_unit` (`base_unit`);

ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `users_username_unique` (`username`),
  ADD KEY `users_role_id_foreign` (`role_id`);

ALTER TABLE `warehouses`
  ADD PRIMARY KEY (`id`);


ALTER TABLE `accounts`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `audit_logs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `brands`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `currencies`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

ALTER TABLE `customers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

ALTER TABLE `deposits`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `deposit_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `expenses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `expense_categories`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `failed_jobs`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `media`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `migrations`
  MODIFY `id` int(10) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=45;

ALTER TABLE `payment_methods`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

ALTER TABLE `payment_purchases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `payment_sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `permissions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

ALTER TABLE `permission_groups`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;

ALTER TABLE `personal_access_tokens`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `products`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=543;

ALTER TABLE `product_variants`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `purchases`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `purchases_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `purchase_returns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `purchase_return_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `purchase_return_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `roles`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `role_permission`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=58;

ALTER TABLE `sales`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=33;

ALTER TABLE `sales_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=128;

ALTER TABLE `sales_returns`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `sales_return_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `sales_return_payments`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `settings`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=29;

ALTER TABLE `stocks`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `suppliers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `transactions`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `transfers`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `transfers_items`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT;

ALTER TABLE `units`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=10;

ALTER TABLE `users`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

ALTER TABLE `warehouses`
  MODIFY `id` bigint(20) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;


ALTER TABLE `audit_logs`
  ADD CONSTRAINT `audit_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `categories`
  ADD CONSTRAINT `categories_parent_id_foreign` FOREIGN KEY (`parent_id`) REFERENCES `categories` (`id`);

ALTER TABLE `payment_purchases`
  ADD CONSTRAINT `payment_purchases_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_purchases_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `payment_sales`
  ADD CONSTRAINT `payment_sales_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `payment_sales_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`);

ALTER TABLE `purchases_items`
  ADD CONSTRAINT `purchases_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `purchases_items_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE;

ALTER TABLE `purchase_returns`
  ADD CONSTRAINT `purchase_returns_purchase_id_foreign` FOREIGN KEY (`purchase_id`) REFERENCES `purchases` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `purchase_returns_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `purchase_return_items`
  ADD CONSTRAINT `purchase_return_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `purchase_return_items_purchase_return_id_foreign` FOREIGN KEY (`purchase_return_id`) REFERENCES `purchase_returns` (`id`) ON DELETE CASCADE;

ALTER TABLE `purchase_return_payments`
  ADD CONSTRAINT `purchase_return_payments_purchase_return_id_foreign` FOREIGN KEY (`purchase_return_id`) REFERENCES `purchase_returns` (`id`) ON DELETE CASCADE;

ALTER TABLE `role_permission`
  ADD CONSTRAINT `role_permission_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `role_permission_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;

ALTER TABLE `sales`
  ADD CONSTRAINT `sales_customer_id_foreign` FOREIGN KEY (`customer_id`) REFERENCES `customers` (`id`) ON DELETE CASCADE;

ALTER TABLE `sales_items`
  ADD CONSTRAINT `sales_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_items_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE;

ALTER TABLE `sales_returns`
  ADD CONSTRAINT `sales_returns_sale_id_foreign` FOREIGN KEY (`sale_id`) REFERENCES `sales` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_returns_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE;

ALTER TABLE `sales_return_items`
  ADD CONSTRAINT `sales_return_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `sales_return_items_sales_return_id_foreign` FOREIGN KEY (`sales_return_id`) REFERENCES `sales_returns` (`id`) ON DELETE CASCADE;

ALTER TABLE `sales_return_payments`
  ADD CONSTRAINT `sales_return_payments_sales_return_id_foreign` FOREIGN KEY (`sales_return_id`) REFERENCES `sales_returns` (`id`) ON DELETE CASCADE;

ALTER TABLE `suppliers`
  ADD CONSTRAINT `suppliers_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

ALTER TABLE `transactions`
  ADD CONSTRAINT `transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`),
  ADD CONSTRAINT `transactions_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`),
  ADD CONSTRAINT `transactions_warehouse_id_foreign` FOREIGN KEY (`warehouse_id`) REFERENCES `warehouses` (`id`);

ALTER TABLE `transfers`
  ADD CONSTRAINT `transfers_from_warehouse_id_foreign` FOREIGN KEY (`from_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  ADD CONSTRAINT `transfers_to_warehouse_id_foreign` FOREIGN KEY (`to_warehouse_id`) REFERENCES `warehouses` (`id`) ON DELETE CASCADE ON UPDATE CASCADE;

ALTER TABLE `transfers_items`
  ADD CONSTRAINT `transfers_items_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  ADD CONSTRAINT `transfers_items_transfer_id_foreign` FOREIGN KEY (`transfer_id`) REFERENCES `transfers` (`id`) ON DELETE CASCADE;

ALTER TABLE `units`
  ADD CONSTRAINT `units_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`);

ALTER TABLE `users`
  ADD CONSTRAINT `users_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
